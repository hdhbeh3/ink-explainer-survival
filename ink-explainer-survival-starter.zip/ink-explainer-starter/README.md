# Ink Explainer — Survival in the Wild

Starter production repository for a limited-animation 2D explainer built with Remotion.

## Current state
This is a runnable scaffold, not the finished illustrated film. It currently contains the ten-scene timeline, placeholder scene cards, a Claude implementation brief, and a GitHub Actions render workflow. Final character art, backgrounds, voiceover, music, and full scene animation still need to be added.

## Requirements
- Node.js 20+
- npm

## Local setup
```bash
npm install
npm run typecheck
npm run dev
```

## Render
```bash
npm run render
```
Output: `out/survival-in-the-wild.mp4`

## GitHub Actions
Push to `main`, or open Actions → Render Ink Explainer → Run workflow. The MP4 is uploaded as an Actions artifact.

## Claude handoff
Open `CLAUDE_PROMPT.md` in Claude and provide the repository files. Ask Claude to implement the brief in-place, then review the diff and run typecheck/render before merging.

## Audio inputs
Place narration at `public/audio/narration.wav` and optional music at `public/audio/music.wav` after the audio components are implemented. Do not commit private API keys or service tokens.
