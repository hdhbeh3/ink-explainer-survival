export type Scene = {
  id: string;
  title: string;
  start: number;
  duration: number;
  narration: string;
  visual: string;
  motion: string;
};

export const scenes: Scene[] = [
  {
    id: 'hook', title: 'The Hook', start: 0, duration: 1350,
    narration: 'Imagine this. You are walking through a beautiful forest. The birds are singing, the trees are moving gently in the wind, and everything seems peaceful. But suddenly, you realize something terrifying. You do not recognize the path anymore. Your phone has no signal. You are lost in the wilderness. What would you do? Survival is not just about strength. It is about making the right decisions at the right time.',
    visual: 'Alex, a simple ink-style explorer with a backpack, stands on a forest trail. Establish a wide forest background.',
    motion: 'Static character pose; slow camera push-out; subtle parallax in background only.'
  },
  {
    id: 'calm', title: 'Stay Calm', start: 1350, duration: 1500,
    narration: 'The first survival skill is controlling your panic. Stop moving for a moment. Take a deep breath and look around. Think about where you came from. Observe the surroundings. Check your supplies and decide what to do next. Remember the word STOP: Stop, Think, Observe, Plan. Moving randomly wastes energy and can make it harder for rescuers to find you.',
    visual: 'Alex in three held poses: worried, thinking, calm. Large STOP / THINK / OBSERVE / PLAN graphic.',
    motion: 'Hold poses; swap expression layers; gentle camera push-in; words appear one at a time.'
  },
  {
    id: 'shelter', title: 'Find or Create Shelter', start: 2850, duration: 1800,
    narration: 'Your next priority is protection from the environment. Rain, wind, extreme heat, and cold can become serious threats. Look for a safe place that protects you from the weather. A tarp or emergency blanket can help create protection. Avoid dry riverbeds, unstable slopes, dead branches, and places at risk of flooding. A shelter does not need to look beautiful. It needs to protect your body and conserve energy.',
    visual: 'Three clean illustrated shelter examples: natural overhang, tarp shelter, emergency blanket.',
    motion: 'Three still illustrations slide or dissolve into place; rain overlay; no character walk cycle.'
  },
  {
    id: 'water', title: 'Find Safe Water', start: 4650, duration: 1800,
    narration: 'Water is essential. Clear-looking water is not necessarily safe to drink. Natural water may contain harmful microorganisms. Whenever possible, use a proper water filter, approved purification tablets, or boil water according to recognized safety guidance. Boiling does not remove chemical contamination. Never assume a river, stream, or lake is automatically safe.',
    visual: 'Stream, container, filter, purification tablets, boiling pot; treatment flow graphic.',
    motion: 'Camera pans across still props; animated arrows and labels; steam loop only.'
  },
  {
    id: 'warmth', title: 'Fire and Warmth', start: 6450, duration: 1650,
    narration: 'Fire can provide warmth, help prepare food, and attract attention, but it also comes with serious risks. A small mistake can start a wildfire. Consider weather, vegetation, local restrictions, and fire danger. Never light a fire when conditions make it unsafe. Warm clothing and an emergency blanket may be safer ways to stay warm.',
    visual: 'Cold forest evening; jacket, flashlight, lighter, waterproof matches, emergency blanket.',
    motion: 'Static character; light flicker only if a permitted, safe fire is depicted; slow camera drift.'
  },
  {
    id: 'food', title: 'Find Food', start: 8100, duration: 1650,
    narration: 'The wilderness contains plants, berries, and mushrooms. Some are edible; others are poisonous. Never eat a wild plant because an animal appears to be eating it. Never assume a berry is safe because it looks familiar. If you cannot identify it with reliable expert knowledge, do not eat it. Emergency food supplies are much safer.',
    visual: 'Unknown berries and mushrooms with warning symbol; emergency ration from backpack.',
    motion: 'Props appear as cut-ins; red warning mark draws on; character remains in held pose.'
  },
  {
    id: 'signal', title: 'Navigation and Signaling', start: 9750, duration: 1800,
    narration: 'If you have a working phone, contact local emergency services. Share your location or GPS coordinates if available. If you cannot contact anyone, use visual and sound signals. A whistle can attract attention without forcing you to shout. Three repeated whistle blasts can be used as a distress signal. A flashlight or reflective object may help rescuers locate you. Stay in a safe, visible place whenever possible.',
    visual: 'Map, compass, phone with no signal, whistle, mirror, flashlight, visible SOS marker.',
    motion: 'Slow pan across gear; signal symbols pulse; no running or walking animation.'
  },
  {
    id: 'wildlife', title: 'Wildlife Safety', start: 11550, duration: 1650,
    narration: 'The wilderness is home to many wild animals. Respect their space. Never approach, feed, chase, or provoke wildlife. If you encounter a potentially dangerous animal, avoid sudden movements and do not run blindly. The correct response depends on the species and situation. Learn about local wildlife before visiting and observe animals from a safe distance.',
    visual: 'Alex and a distant wild animal separated by clear space; species-neutral warning icons.',
    motion: 'Hold both figures; slow camera pull-back; small attention cue around distance boundary.'
  },
  {
    id: 'kit', title: 'The Survival Kit', start: 13200, duration: 1650,
    narration: 'A well-prepared backpack can make an enormous difference. Carry drinking water and a way to treat additional water. Bring a first-aid kit, navigation tools, a flashlight, a whistle, and emergency shelter. Pack extra clothing, appropriate food, and essential personal supplies. Keep your phone charged and consider a backup power source. Tell someone your route and expected return time before leaving.',
    visual: 'Backpack opens; labeled survival items arranged neatly around it.',
    motion: 'Items pop or slide in sequentially; backpack stays still; camera remains mostly locked.'
  },
  {
    id: 'ending', title: 'The Final Lesson', start: 14850, duration: 1350,
    narration: 'Eventually, Alex hears something in the distance. A rescue team is approaching. He uses his whistle to attract their attention. This story teaches us something important. Survival is not about being the strongest person in the forest. It is about staying calm, protecting yourself, managing your resources, and making intelligent decisions. Prepare properly, respect nature, and always return safely.',
    visual: 'Rescue team appears far away; Alex signals; end card: STAY CALM. STAY PREPARED. STAY SAFE.',
    motion: 'Slow zoom-out; rescue team revealed by background cut; end card fades in.'
  }
];
