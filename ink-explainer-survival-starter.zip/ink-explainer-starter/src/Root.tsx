import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';

export const Root: React.FC = () => (
  <Composition
    id="SurvivalInTheWild"
    component={Video}
    width={1920}
    height={1080}
    fps={30}
    durationInFrames={16200}
  />
);
