import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import type {Scene as SceneData} from './timeline';

export const Scene: React.FC<{scene: SceneData}> = ({scene}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const progress = frame / Math.max(1, durationInFrames);
  const zoom = interpolate(frame, [0, durationInFrames], [1, 1.035]);
  const fadeIn = interpolate(frame, [0, 18], [0, 1], {extrapolateRight: 'clamp'});
  const fadeOut = interpolate(frame, [durationInFrames - 18, durationInFrames], [1, 0], {extrapolateLeft: 'clamp'});
  const opacity = Math.min(fadeIn, fadeOut);

  return (
    <AbsoluteFill style={{backgroundColor: '#dce9d8', opacity, overflow: 'hidden'}}>
      <AbsoluteFill style={{transform: `scale(${zoom})`, justifyContent: 'center', alignItems: 'center'}}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(180deg, #9fc99e 0%, #c8dfbd 68%, #8cb47d 68%, #8cb47d 100%)'
        }} />
        <div style={{
          position: 'absolute', top: 90, left: 110, right: 110, height: 6,
          background: '#273329', opacity: 0.75
        }} />
        <div style={{
          position: 'relative', width: '78%', padding: 58, border: '7px solid #202820',
          borderRadius: 18, backgroundColor: 'rgba(248,250,240,0.94)',
          boxShadow: '14px 16px 0 rgba(25,40,27,0.18)'
        }}>
          <div style={{fontFamily: 'Arial, sans-serif', fontSize: 28, letterSpacing: 5, color: '#52734e', fontWeight: 700}}>
            INK EXPLAINER • SURVIVAL IN THE WILD
          </div>
          <div style={{fontFamily: 'Arial, sans-serif', fontSize: 76, lineHeight: 1.05, fontWeight: 900, color: '#17231a', marginTop: 22}}>
            {scene.title}
          </div>
          <div style={{fontFamily: 'Arial, sans-serif', fontSize: 30, lineHeight: 1.35, color: '#344536', marginTop: 28}}>
            {scene.visual}
          </div>
          <div style={{marginTop: 30, height: 8, background: '#d7e2d1', borderRadius: 8}}>
            <div style={{height: 8, width: `${Math.max(2, progress * 100)}%`, background: '#52734e', borderRadius: 8}} />
          </div>
        </div>
        <div style={{
          position: 'absolute', bottom: 64, left: 110, right: 110,
          fontFamily: 'Arial, sans-serif', fontSize: 22, color: '#203324',
          display: 'flex', justifyContent: 'space-between'
        }}>
          <span>LIMITED 2D ANIMATION • HELD POSES • CAMERA MOVEMENT</span>
          <span>{String(Math.round(progress * 100)).padStart(2, '0')}%</span>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
