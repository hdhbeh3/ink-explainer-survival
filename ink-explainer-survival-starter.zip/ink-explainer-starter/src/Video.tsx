import React from 'react';
import {AbsoluteFill, Series} from 'remotion';
import {Scene} from './Scene';
import {scenes} from './timeline';

export const Video: React.FC = () => (
  <AbsoluteFill>
    <Series>
      {scenes.map((scene) => (
        <Series.Sequence key={scene.id} durationInFrames={scene.duration}>
          <Scene scene={scene} />
        </Series.Sequence>
      ))}
    </Series>
  </AbsoluteFill>
);
