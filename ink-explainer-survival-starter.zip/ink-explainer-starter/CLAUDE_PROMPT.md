# Claude implementation brief — Ink Explainer: Survival in the Wild

You are the implementation engineer for this repository. Build on the existing Remotion + React + TypeScript scaffold. Do not replace the production approach.

## Target
- 16:9, 1920x1080, 30 fps.
- Target runtime 8–10 minutes.
- English narration.
- Visual style: hand-drawn 2D ink explainer, clean black outlines, simple white-faced stick-figure characters, muted green/earth-tone backgrounds, readable educational props.
- Limited animation only: characters mostly hold poses. Do NOT create continuous walk cycles, running cycles, lip-sync, or full-body acting.
- Allowed motion: eye/expression swaps, occasional arm/hand gesture swaps, object reveals, simple prop movement, slow camera push/pull/pan, subtle background parallax, fades and wipes.
- Maintain consistent character model and proportions across all scenes.

## Work to do
1. Inspect every existing file before editing.
2. Improve the scene timeline and ensure all scene durations sum to 8–10 minutes at 30 fps.
3. Replace the current text-card placeholder visual with a reusable illustrated scene system. Create reusable components for the main character, forest/home/stream/shelter backgrounds, props, labels, and transitions.
4. Use original vector/CSS/SVG illustrations where practical. Keep character parts separable so a held pose can be reused with small expression/gesture changes.
5. Keep narration text synchronized to scene timing. Add audio support for `public/audio/narration.wav` (or a clearly documented alternate file path); if the file is absent, the project must still preview and render without crashing.
6. Add optional low-volume background music support, also graceful when no file exists.
7. Add subtitles/captions with readable safe margins.
8. Keep all animation deterministic and render-safe. Avoid browser-only APIs and random values.
9. Add a README with exact local setup, preview, render, and GitHub Actions instructions.
10. Add validation so the timeline duration is checked and typecheck passes.

## Safety and factual handling
This is general outdoor safety education, not a substitute for local emergency guidance. Do not add precise survival instructions that vary by region/species unless verified. Keep the existing script's cautions: unknown plants must not be eaten; natural water is not automatically safe; boiling does not remove chemical contamination; fire may be prohibited or dangerous; wildlife responses depend on species and situation; contact local emergency services when possible.

## Acceptance criteria
- `npm run typecheck` passes.
- `npm run render` produces `out/survival-in-the-wild.mp4`.
- No missing-asset crash when narration/music/images have not yet been supplied.
- The characters remain mostly static, with limited pose/expression changes and camera/prop motion only.
- Final runtime is 8–10 minutes.
- GitHub Actions workflow uploads the MP4 as an artifact.
- Report files changed, commands run, test results, and any remaining manual inputs. Do not claim success for checks not actually run.
