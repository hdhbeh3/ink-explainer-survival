export const INK = '#1c241d';
export const PAPER = '#f6f1df';
export const WHITE = '#fffdf5';
export const GREEN_DARK = '#3f6b45';
export const GREEN = '#6fa468';
export const GREEN_LIGHT = '#a9cfa4';
export const EARTH = '#b98a58';
export const SAND = '#e2cf9f';
export const ORANGE = '#e08a2e';
export const RED = '#d2402f';
export const BLUE = '#6bb6d6';
export const YELLOW = '#f2c744';

export const FONT_HAND = "'Patrick Hand', 'Comic Sans MS', 'Chalkboard SE', cursive, sans-serif";
export const FONT_SUB = "'Helvetica Neue', Arial, 'DejaVu Sans', sans-serif";

/** Common outline style for every illustrated shape (thick, clean, rounded). */
export const OUT = {
  stroke: INK,
  strokeWidth: 8,
  strokeLinejoin: 'round' as const,
  strokeLinecap: 'round' as const,
};
export const OUT_THIN = {...OUT, strokeWidth: 5};

/** Deterministic pseudo random generator (render-safe, no Math.random). */
export const mulberry32 = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};
