import React from 'react';
import {Audio, interpolate, Sequence, staticFile} from 'remotion';
import {NARRATION_LEAD_IN} from './captions';
import {cueFrame, manifest} from './cues';
import {scenes, TOTAL_FRAMES, type SfxName} from './timeline';

const MUSIC_VOLUME = 0.11;

/** Length in frames of each one-shot sound effect. Ambient beds loop until the scene ends. */
const SFX_FRAMES: Record<SfxName, number> = {
  pop: 9, whoosh: 16, whistle: 66, ding: 20, warning: 16, rain: 0, birds: 0,
};
const AMBIENT_FRAMES: Partial<Record<SfxName, number>> = {birds: 420};

/**
 * All audio: looping original music bed, SFX cues locked to the narration, and narration clips.
 * Narration is optional: if no clip exists for a scene nothing is played and nothing crashes.
 */
export const AudioLayer: React.FC = () => (
  <>
    <Audio
      src={staticFile('audio/music.wav')}
      loop
      volume={(f) =>
        MUSIC_VOLUME *
        interpolate(f, [0, 90, TOTAL_FRAMES - 150, TOTAL_FRAMES], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})
      }
    />
    {scenes.map((scene) => {
      const clip = manifest.narration[scene.id];
      return (
        <React.Fragment key={scene.id}>
          {clip && (
            <Sequence from={scene.start + NARRATION_LEAD_IN} durationInFrames={scene.duration - NARRATION_LEAD_IN}>
              <Audio src={staticFile(clip.file)} volume={1} />
            </Sequence>
          )}
          {scene.sfx.map((cue, i) => {
            const at = cueFrame(scene, cue.phrase);
            const remaining = scene.duration - at;
            const len = cue.name === 'rain' ? remaining : AMBIENT_FRAMES[cue.name] ?? SFX_FRAMES[cue.name];
            const looped = cue.name === 'rain' || cue.name === 'birds';
            return (
              <Sequence key={`${scene.id}-${i}`} from={scene.start + at} durationInFrames={Math.max(1, Math.min(len, remaining))}>
                <Audio src={staticFile(`audio/sfx/${cue.name}.wav`)} volume={cue.volume} loop={looped} />
              </Sequence>
            );
          })}
        </React.Fragment>
      );
    })}
    {manifest.fullTrack ? <Audio src={staticFile(manifest.fullTrack)} volume={1} /> : null}
  </>
);
