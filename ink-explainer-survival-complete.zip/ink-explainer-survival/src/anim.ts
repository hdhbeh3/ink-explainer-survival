import {Easing, interpolate} from 'remotion';

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

/** 0 -> 1 eased reveal beginning at frame `at`. */
export const appear = (frame: number, at: number, dur = 14): number =>
  interpolate(frame, [at, at + dur], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });

/** Pop-in scale with a little overshoot (0 before `at`). */
export const pop = (frame: number, at: number, dur = 16): number =>
  interpolate(frame, [at, at + dur * 0.6, at + dur], [0, 1.12, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.quad),
  });

/** Linear 0 -> 1 progress between two frames. */
export const prog = (frame: number, from: number, to: number): number =>
  interpolate(frame, [from, to], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

/** Gentle repeating pulse in [0,1]. */
export const pulse = (frame: number, period = 45): number =>
  0.5 + 0.5 * Math.sin((frame / period) * Math.PI * 2);
