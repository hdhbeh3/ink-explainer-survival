import React, {useMemo} from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {buildCaptions} from './captions';
import {speechFramesFor} from './cues';
import {FONT_SUB, INK, WHITE} from './theme';
import type {Scene} from './timeline';

export const Subtitles: React.FC<{scene: Scene}> = ({scene}) => {
  const frame = useCurrentFrame();
  const captions = useMemo(() => buildCaptions(scene.narration, speechFramesFor(scene)), [scene]);
  const active = captions.find((c) => frame >= c.from && frame < c.to);
  if (!active) return null;
  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 72, paddingLeft: 140, paddingRight: 140}}>
      <div
        style={{
          maxWidth: 1500,
          textAlign: 'center',
          fontFamily: FONT_SUB,
          fontWeight: 700,
          fontSize: 46,
          lineHeight: 1.25,
          color: WHITE,
          background: 'rgba(28,36,29,0.82)',
          border: `4px solid ${INK}`,
          borderRadius: 18,
          padding: '14px 34px',
        }}
      >
        {active.text}
      </div>
    </AbsoluteFill>
  );
};
