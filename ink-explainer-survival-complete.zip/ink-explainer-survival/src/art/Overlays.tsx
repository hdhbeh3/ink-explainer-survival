import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {mulberry32} from '../theme';

/** Camera: slow deterministic push / pull / pan over the scene's duration. */
export type CamState = {zoom: number; x: number; y: number};
export const Camera: React.FC<{from: CamState; to: CamState; children: React.ReactNode}> = ({from, to, children}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const k = frame / Math.max(1, durationInFrames - 1);
  const e = k * k * (3 - 2 * k); // smoothstep
  const z = from.zoom + (to.zoom - from.zoom) * e;
  const x = from.x + (to.x - from.x) * e;
  const y = from.y + (to.y - from.y) * e;
  return (
    <AbsoluteFill style={{transform: `translate(${x}px, ${y}px) scale(${z})`, transformOrigin: '50% 55%'}}>{children}</AbsoluteFill>
  );
};

/** Full-frame SVG stage in 1920x1080 coordinates for characters and props. */
export const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width="100%" height="100%" viewBox="0 0 1920 1080" style={{position: 'absolute', inset: 0}}>{children}</svg>
);

/** Slanted rain streaks, deterministic. */
export const Rain: React.FC<{intensity?: number}> = ({intensity = 1}) => {
  const frame = useCurrentFrame();
  const rnd = mulberry32(5);
  const drops: React.ReactNode[] = [];
  const count = Math.round(110 * intensity);
  for (let i = 0; i < count; i++) {
    const bx = rnd() * 2200 - 150;
    const speed = 22 + rnd() * 16;
    const by = (rnd() * 1300 + frame * speed) % 1300 - 100;
    drops.push(<line key={i} x1={bx} y1={by} x2={bx - 18} y2={by + 56} stroke="#e8f4fa" strokeWidth={4} strokeLinecap="round" opacity={0.7} />);
  }
  return (
    <svg width="100%" height="100%" viewBox="0 0 1920 1080" style={{position: 'absolute', inset: 0}}>
      <rect width={1920} height={1080} fill="#2c3f55" opacity={0.18 * intensity} />
      {drops}
    </svg>
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 58%, rgba(20,30,20,0.34) 100%)', pointerEvents: 'none'}} />
);
