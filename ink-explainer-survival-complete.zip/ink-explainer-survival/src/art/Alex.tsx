import React from 'react';
import {useCurrentFrame} from 'remotion';
import {BLUE, INK, ORANGE, OUT, WHITE} from '../theme';

export type Expression = 'worried' | 'thinking' | 'calm' | 'happy' | 'surprised' | 'determined';
export type ArmPose = 'down' | 'up' | 'point' | 'chin' | 'wide' | 'hold' | 'shield' | 'cheer';

type Pt = [number, number];
type Arm = {c: Pt; h: Pt};
const ARMS: Record<ArmPose, {L: Arm; R: Arm}> = {
  down: {L: {c: [-75, -230], h: [-70, -170]}, R: {c: [75, -230], h: [70, -170]}},
  up: {L: {c: [-75, -230], h: [-70, -170]}, R: {c: [105, -320], h: [98, -425]}},
  point: {L: {c: [-75, -230], h: [-70, -170]}, R: {c: [110, -285], h: [200, -300]}},
  chin: {L: {c: [-45, -225], h: [40, -245]}, R: {c: [75, -255], h: [14, -305]}},
  wide: {L: {c: [-115, -300], h: [-170, -330]}, R: {c: [115, -300], h: [170, -330]}},
  hold: {L: {c: [-62, -235], h: [-22, -232]}, R: {c: [62, -235], h: [22, -232]}},
  shield: {L: {c: [-95, -300], h: [-70, -385]}, R: {c: [95, -300], h: [70, -385]}},
  cheer: {L: {c: [-105, -335], h: [-98, -432]}, R: {c: [105, -335], h: [98, -432]}},
};

export type AlexProps = {
  x?: number;
  y?: number;
  scale?: number;
  flip?: boolean;
  expression?: Expression;
  arms?: ArmPose;
  pack?: boolean;
  /** Extra items drawn in Alex's local coordinate system (e.g. a phone in his hands). */
  children?: React.ReactNode;
};

const Eyes: React.FC<{expression: Expression; blink: boolean}> = ({expression, blink}) => {
  const eye = (cx: number, dx = 0, dy = 0, r = 5.5) => (
    <ellipse key={cx} cx={cx + dx} cy={-352 + dy} rx={r} ry={blink ? 0.8 : r * 1.25} fill={INK} />
  );
  switch (expression) {
    case 'calm':
      return (
        <g fill="none" {...OUT} strokeWidth={5}>
          <path d="M -28 -352 Q -19 -344 -10 -352" />
          <path d="M 10 -352 Q 19 -344 28 -352" />
        </g>
      );
    case 'surprised':
      return (
        <g>
          {[-18, 18].map((cx) => (
            <g key={cx}>
              <circle cx={cx} cy={-352} r={11} fill={WHITE} stroke={INK} strokeWidth={4} />
              <circle cx={cx} cy={-352} r={4.5} fill={INK} />
            </g>
          ))}
        </g>
      );
    case 'thinking':
      return <g>{[-18, 18].map((cx) => eye(cx, 4, -4))}</g>;
    default:
      return <g>{[-18, 18].map((cx) => eye(cx))}</g>;
  }
};

const Face: React.FC<{expression: Expression; blink: boolean}> = ({expression, blink}) => {
  const line = {fill: 'none', ...OUT, strokeWidth: 5} as const;
  return (
    <g>
      <Eyes expression={expression} blink={blink} />
      {expression === 'worried' && (
        <g>
          <path d="M -32 -364 L -10 -374" {...line} />
          <path d="M 10 -374 L 32 -364" {...line} />
          <path d="M -15 -324 Q -8 -333 0 -326 Q 8 -319 15 -327" {...line} />
          <path d="M 50 -378 Q 58 -362 50 -358 Q 42 -362 50 -378 Z" fill={BLUE} stroke={INK} strokeWidth={4} />
        </g>
      )}
      {expression === 'thinking' && (
        <g>
          <path d="M -32 -370 L -10 -370" {...line} />
          <path d="M 10 -380 L 32 -372" {...line} />
          <path d="M -8 -326 L 11 -331" {...line} />
        </g>
      )}
      {expression === 'calm' && <path d="M -15 -330 Q 0 -319 15 -330" {...line} />}
      {expression === 'happy' && (
        <g>
          <path d="M -30 -372 Q -20 -380 -10 -372" {...line} />
          <path d="M 10 -372 Q 20 -380 30 -372" {...line} />
          <path d="M -19 -334 Q 0 -306 19 -334 Z" fill={WHITE} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
        </g>
      )}
      {expression === 'surprised' && (
        <g>
          <path d="M -32 -378 Q -18 -388 -8 -378" {...line} />
          <path d="M 8 -378 Q 18 -388 32 -378" {...line} />
          <ellipse cx={0} cy={-322} rx={7} ry={10} fill={INK} />
        </g>
      )}
      {expression === 'determined' && (
        <g>
          <path d="M -32 -372 L -10 -364" {...line} />
          <path d="M 10 -364 L 32 -372" {...line} />
          <path d="M -12 -327 L 12 -327" {...line} />
        </g>
      )}
    </g>
  );
};

const ArmPath: React.FC<{side: 'L' | 'R'; pose: ArmPose}> = ({side, pose}) => {
  const a = ARMS[pose][side];
  const sx = side === 'L' ? -40 : 40;
  return (
    <g>
      <path d={`M ${sx} -282 Q ${a.c[0]} ${a.c[1]} ${a.h[0]} ${a.h[1]}`} fill="none" stroke={INK} strokeWidth={26} strokeLinecap="round" />
      <path d={`M ${sx} -282 Q ${a.c[0]} ${a.c[1]} ${a.h[0]} ${a.h[1]}`} fill="none" stroke={ORANGE} strokeWidth={14} strokeLinecap="round" />
      <circle cx={a.h[0]} cy={a.h[1]} r={13} fill={WHITE} stroke={INK} strokeWidth={6} />
    </g>
  );
};

/**
 * Alex - the single reusable main character. Feet stand at (x, y).
 * Body parts are separate groups so a held pose only swaps expression / arm layers.
 */
export const Alex: React.FC<AlexProps> = ({
  x = 960,
  y = 900,
  scale = 1,
  flip = false,
  expression = 'calm',
  arms = 'down',
  pack = true,
  children,
}) => {
  const frame = useCurrentFrame();
  const breathe = Math.sin((frame / 30) * Math.PI * 0.7) * 2; // subtle idle only
  const blink = frame % 120 > 115;
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -scale : scale} ${scale})`}>
      {/* ground shadow */}
      <ellipse cx={0} cy={6} rx={85} ry={14} fill="rgba(0,0,0,0.16)" />
      {/* backpack behind body */}
      {pack && (
        <g>
          <rect x={-66} y={-292} width={132} height={150} rx={30} fill="#4f7a4a" {...OUT} />
          <rect x={-40} y={-196} width={80} height={44} rx={12} fill="#3f6b45" {...OUT} strokeWidth={5} />
        </g>
      )}
      {/* legs */}
      <path d="M -22 -150 L -32 -14" fill="none" stroke={INK} strokeWidth={26} strokeLinecap="round" />
      <path d="M 22 -150 L 32 -14" fill="none" stroke={INK} strokeWidth={26} strokeLinecap="round" />
      <path d="M -22 -150 L -32 -14" fill="none" stroke="#4a5d8a" strokeWidth={14} strokeLinecap="round" />
      <path d="M 22 -150 L 32 -14" fill="none" stroke="#4a5d8a" strokeWidth={14} strokeLinecap="round" />
      <ellipse cx={-42} cy={-6} rx={28} ry={12} fill="#5a4630" {...OUT} strokeWidth={6} />
      <ellipse cx={42} cy={-6} rx={28} ry={12} fill="#5a4630" {...OUT} strokeWidth={6} />
      <g transform={`translate(0 ${breathe})`}>
        {/* torso (jacket) */}
        <path d="M -44 -290 Q -50 -222 -42 -146 L 42 -146 Q 50 -222 44 -290 Q 0 -306 -44 -290 Z" fill={ORANGE} {...OUT} />
        <path d="M 0 -296 L 0 -148" stroke={INK} strokeWidth={5} strokeLinecap="round" />
        {pack && (
          <g fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round">
            <path d="M -28 -292 L -30 -170" />
            <path d="M 28 -292 L 30 -170" />
          </g>
        )}
        <ArmPath side="L" pose={arms} />
        <ArmPath side="R" pose={arms} />
        {children}
        {/* head */}
        <rect x={-10} y={-306} width={20} height={20} fill={WHITE} stroke={INK} strokeWidth={6} />
        <circle cx={0} cy={-350} r={54} fill={WHITE} {...OUT} />
        {/* explorer hat */}
        <path d="M -52 -366 Q -50 -420 0 -420 Q 50 -420 52 -366 Q 0 -378 -52 -366 Z" fill="#7a5a34" {...OUT} />
        <path d="M -78 -366 Q 0 -388 78 -366 Q 0 -352 -78 -366 Z" fill="#8b6a40" {...OUT} strokeWidth={6} />
        <Face expression={expression} blink={blink} />
      </g>
    </g>
  );
};
