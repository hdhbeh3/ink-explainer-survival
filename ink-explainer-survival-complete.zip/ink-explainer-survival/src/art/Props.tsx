import React from 'react';
import {BLUE, FONT_HAND, INK, ORANGE, OUT, RED, SAND, WHITE, YELLOW} from '../theme';

type P = {x?: number; y?: number; s?: number; r?: number; o?: number};
const T = ({x = 0, y = 0, s = 1, r = 0, o = 1}: P) => ({
  transform: `translate(${x} ${y}) rotate(${r}) scale(${s})`,
  opacity: o,
});
const sw = (w = 7) => ({stroke: INK, strokeWidth: w, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const});

export const Phone: React.FC<P & {noSignal?: boolean}> = ({noSignal = true, ...p}) => (
  <g {...T(p)}>
    <rect x={-46} y={-80} width={92} height={160} rx={14} fill="#2a2f2b" {...sw()} />
    <rect x={-37} y={-64} width={74} height={118} rx={4} fill="#dff0f5" {...sw(3)} />
    <g {...sw(5)} fill="none">
      <path d="M -26 -30 L -26 -22" /><path d="M -14 -36 L -14 -22" /><path d="M -2 -42 L -2 -22" /><path d="M 10 -48 L 10 -22" />
    </g>
    {noSignal && <path d="M -30 -50 L 30 4" stroke={RED} strokeWidth={8} strokeLinecap="round" />}
    <text x={0} y={36} textAnchor="middle" fontFamily={FONT_HAND} fontSize={17} fill={INK}>NO SERVICE</text>
  </g>
);

export const Whistle: React.FC<P> = (p) => (
  <g {...T(p)}>
    <path d="M -60 -20 L 20 -20 Q 62 -20 62 18 Q 62 56 20 56 Q -20 56 -20 20 L -60 20 Z" fill={YELLOW} {...sw()} />
    <circle cx={22} cy={22} r={10} fill={WHITE} {...sw(5)} />
    <path d="M -20 -20 L -20 20" {...sw(5)} />
    <circle cx={30} cy={-36} r={9} fill="none" {...sw(5)} />
  </g>
);

export const MapSheet: React.FC<P> = (p) => (
  <g {...T(p)}>
    <path d="M -110 -80 L -40 -92 L 40 -80 L 110 -92 L 110 84 L 40 96 L -40 84 L -110 96 Z" fill="#f4e7bd" {...sw()} />
    <path d="M -40 -92 L -40 84 M 40 -80 L 40 96" {...sw(4)} fill="none" />
    <path d="M -90 40 Q -60 -10 -20 20 T 40 -20 T 90 10" fill="none" stroke={RED} strokeWidth={6} strokeDasharray="12 10" strokeLinecap="round" />
    <path d="M 70 -40 l 14 20 l 14 -20 Z" fill="#4f8a52" {...sw(4)} />
    <path d="M -80 -50 l 14 -22 l 14 22 Z" fill="#4f8a52" {...sw(4)} />
  </g>
);

export const Compass: React.FC<P & {needle?: number}> = ({needle = 0, ...p}) => (
  <g {...T(p)}>
    <circle r={66} fill="#c7a15a" {...sw()} />
    <circle r={50} fill={WHITE} {...sw(5)} />
    <text y={-30} textAnchor="middle" fontFamily={FONT_HAND} fontSize={20} fill={INK}>N</text>
    <g transform={`rotate(${needle})`}>
      <path d="M 0 -38 L 10 0 L -10 0 Z" fill={RED} {...sw(4)} />
      <path d="M 0 38 L 10 0 L -10 0 Z" fill="#cfd6d2" {...sw(4)} />
    </g>
  </g>
);

export const Flashlight: React.FC<P & {beam?: boolean}> = ({beam = false, ...p}) => (
  <g {...T(p)}>
    {beam && <path d="M 70 -22 L 360 -120 L 360 120 L 70 22 Z" fill="rgba(255,236,150,0.45)" />}
    <rect x={-70} y={-20} width={110} height={40} rx={8} fill="#3d4a6b" {...sw()} />
    <path d="M 40 -34 L 76 -44 L 76 44 L 40 34 Z" fill={YELLOW} {...sw()} />
    <path d="M -30 -20 L -30 20" {...sw(5)} />
  </g>
);

export const Mirror: React.FC<P & {glint?: number}> = ({glint = 0, ...p}) => (
  <g {...T(p)}>
    <circle r={52} fill="#e2f2f6" {...sw()} />
    <path d="M -28 -10 L 6 -34" stroke={WHITE} strokeWidth={8} strokeLinecap="round" opacity={0.5 + 0.5 * glint} />
    <path d="M 0 52 L 0 84" {...sw(12)} />
    {glint > 0.6 && <g stroke={YELLOW} strokeWidth={6} strokeLinecap="round"><path d="M 70 -70 L 100 -100" /><path d="M 82 -30 L 120 -34" /><path d="M 40 -84 L 44 -122" /></g>}
  </g>
);

export const Bottle: React.FC<P & {fill?: string}> = ({fill = BLUE, ...p}) => (
  <g {...T(p)}>
    <path d="M -26 -60 L 26 -60 L 26 -80 L -26 -80 Z" fill="#3f6b45" {...sw()} />
    <path d="M -26 -60 Q -44 -30 -42 0 L -42 70 Q -42 90 -22 90 L 22 90 Q 42 90 42 70 L 42 0 Q 44 -30 26 -60 Z" fill="#eaf6fa" {...sw()} />
    <path d="M -36 10 L 36 10 L 36 70 Q 36 84 22 84 L -22 84 Q -36 84 -36 70 Z" fill={fill} stroke="none" />
  </g>
);

export const Filter: React.FC<P> = (p) => (
  <g {...T(p)}>
    <rect x={-34} y={-90} width={68} height={160} rx={18} fill="#6b8fa8" {...sw()} />
    <rect x={-34} y={-30} width={68} height={50} fill="#cfe5ee" {...sw(5)} />
    <path d="M 0 -90 L 0 -130 Q 0 -150 22 -150 L 60 -150" fill="none" {...sw(9)} />
    <path d="M 0 70 L 0 110" {...sw(9)} />
  </g>
);

export const Tablets: React.FC<P> = (p) => (
  <g {...T(p)}>
    <rect x={-44} y={-30} width={88} height={64} rx={8} fill="#f1f1f1" {...sw()} />
    <g fill={WHITE} {...sw(5)}>
      <circle cx={-18} cy={-6} r={11} /><circle cx={18} cy={-6} r={11} /><circle cx={0} cy={16} r={11} />
    </g>
  </g>
);

export const Pot: React.FC<P & {steam?: number}> = ({steam = 0, ...p}) => (
  <g {...T(p)}>
    <path d="M -70 -30 L 70 -30 L 62 60 Q 60 78 40 78 L -40 78 Q -60 78 -62 60 Z" fill="#8a949a" {...sw()} />
    <path d="M -70 -30 L -96 -20 M 70 -30 L 96 -20" {...sw(9)} />
    <path d="M -76 -34 L 76 -34" {...sw(10)} />
    <path d="M -34 8 Q -20 -12 -8 8 T 22 8" fill="none" stroke={WHITE} strokeWidth={6} strokeLinecap="round" />
    {[-30, 0, 30].map((sx, i) => (
      <path key={i} d={`M ${sx} -50 q -14 -22 0 -44 q 14 -22 0 -44`} fill="none" stroke="#ffffff" strokeWidth={8} strokeLinecap="round" opacity={0.85 * Math.max(0, Math.sin(steam / 10 + i * 1.7) * 0.5 + 0.5)} transform={`translate(0 ${-((steam + i * 14) % 30)})`} />
    ))}
  </g>
);

export const Berries: React.FC<P> = (p) => (
  <g {...T(p)}>
    <path d="M 0 60 Q -4 0 0 -40" fill="none" stroke="#3f6b45" strokeWidth={9} strokeLinecap="round" />
    <path d="M 0 -10 Q -50 -30 -62 -6 Q -30 14 0 -10 Z M 0 -30 Q 50 -50 62 -26 Q 30 -6 0 -30 Z" fill="#6fa468" {...sw(5)} />
    {[[-18, -50], [14, -60], [0, -78], [26, -38], [-30, -30]].map(([bx, by], i) => (
      <circle key={i} cx={bx} cy={by} r={13} fill="#7b3fa0" {...sw(5)} />
    ))}
  </g>
);

export const Mushroom: React.FC<P> = (p) => (
  <g {...T(p)}>
    <path d="M -20 70 Q -26 10 -16 0 L 16 0 Q 26 10 20 70 Z" fill="#f1e8d3" {...sw()} />
    <path d="M -80 6 Q -80 -70 0 -76 Q 80 -70 80 6 Q 0 22 -80 6 Z" fill="#c4553a" {...sw()} />
    {[[-40, -30], [10, -48], [44, -20], [-6, -12]].map(([mx, my], i) => <circle key={i} cx={mx} cy={my} r={9} fill={WHITE} {...sw(4)} />)}
  </g>
);

export const WarningMark: React.FC<P & {draw?: number}> = ({draw = 1, ...p}) => (
  <g {...T(p)}>
    <circle r={78} fill="none" stroke={RED} strokeWidth={14} strokeDasharray={490} strokeDashoffset={490 * (1 - draw)} strokeLinecap="round" transform="rotate(-90)" />
    <path d="M -54 -54 L 54 54" stroke={RED} strokeWidth={14} strokeLinecap="round" strokeDasharray={160} strokeDashoffset={160 * (1 - Math.max(0, draw * 2 - 1))} />
  </g>
);

export const WarningTriangle: React.FC<P> = (p) => (
  <g {...T(p)}>
    <path d="M 0 -70 L 70 50 L -70 50 Z" fill={YELLOW} {...sw(8)} />
    <path d="M 0 -30 L 0 14" {...sw(10)} />
    <circle cy={34} r={6} fill={INK} />
  </g>
);

export const Ration: React.FC<P> = (p) => (
  <g {...T(p)}>
    <rect x={-70} y={-36} width={140} height={72} rx={10} fill="#d79a4a" {...sw()} />
    <rect x={-70} y={-12} width={140} height={24} fill="#f4e2b6" {...sw(5)} />
    <text y={7} textAnchor="middle" fontFamily={FONT_HAND} fontSize={20} fill={INK}>ENERGY BAR</text>
  </g>
);

export const Jacket: React.FC<P> = (p) => (
  <g {...T(p)}>
    <path d="M -50 -70 L -90 -30 L -76 30 L -48 6 L -48 80 L 48 80 L 48 6 L 76 30 L 90 -30 L 50 -70 Q 0 -50 -50 -70 Z" fill="#5b7fb5" {...sw()} />
    <path d="M 0 -56 L 0 80" {...sw(5)} />
  </g>
);

export const Lighter: React.FC<P> = (p) => (
  <g {...T(p)}>
    <rect x={-22} y={-40} width={44} height={90} rx={8} fill="#c93a3a" {...sw()} />
    <rect x={-14} y={-62} width={28} height={22} fill="#c9ced0" {...sw(5)} />
  </g>
);

export const Matches: React.FC<P> = (p) => (
  <g {...T(p)}>
    <rect x={-50} y={-30} width={100} height={60} rx={6} fill="#2f6f9a" {...sw()} />
    <text y={8} textAnchor="middle" fontFamily={FONT_HAND} fontSize={17} fill={WHITE}>WATERPROOF</text>
  </g>
);

export const Blanket: React.FC<P> = (p) => (
  <g {...T(p)}>
    <path d="M -110 -60 L 110 -60 L 96 60 L -96 60 Z" fill="#e6d28a" {...sw()} />
    <path d="M -70 -40 l 30 70 M -20 -50 l 30 90 M 30 -50 l 26 90" stroke="#fff2b8" strokeWidth={9} strokeLinecap="round" opacity={0.8} />
  </g>
);

export const Tarp: React.FC<P> = (p) => (
  <g {...T(p)}>
    <path d="M -180 70 L 0 -120 L 180 70 Z" fill="#4f7fa8" {...sw()} />
    <path d="M 0 -120 L 0 70" {...sw(5)} />
    <path d="M -180 70 L -200 100 M 180 70 L 200 100" {...sw(8)} />
    <path d="M -180 70 L 180 70" {...sw(8)} />
  </g>
);

export const FirstAid: React.FC<P> = (p) => (
  <g {...T(p)}>
    <rect x={-60} y={-44} width={120} height={88} rx={12} fill={WHITE} {...sw()} />
    <path d="M -10 -26 L 10 -26 L 10 -10 L 26 -10 L 26 10 L 10 10 L 10 26 L -10 26 L -10 10 L -26 10 L -26 -10 L -10 -10 Z" fill={RED} {...sw(4)} />
    <path d="M -20 -44 Q 0 -66 20 -44" fill="none" {...sw(6)} />
  </g>
);

export const Sign: React.FC<P & {text: string; w?: number; color?: string}> = ({text, w = 220, color = '#f4e7bd', ...p}) => (
  <g {...T(p)}>
    <rect x={-w / 2} y={-34} width={w} height={68} rx={12} fill={color} {...sw()} />
    <text y={11} textAnchor="middle" fontFamily={FONT_HAND} fontSize={38} fill={INK}>{text}</text>
  </g>
);

/** Hand-lettered label with pointer line, used for explainer annotations. */
export const Label: React.FC<{x: number; y: number; text: string; size?: number; color?: string; o?: number; s?: number}> = ({x, y, text, size = 44, color = WHITE, o = 1, s = 1}) => {
  const w = text.length * size * 0.56 + 48;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
      <rect x={-w / 2} y={-size * 0.8} width={w} height={size * 1.5} rx={14} fill={color} {...sw(6)} />
      <text y={size * 0.28} textAnchor="middle" fontFamily={FONT_HAND} fontSize={size} fill={INK}>{text}</text>
    </g>
  );
};

export const ArrowRight: React.FC<P & {len?: number; draw?: number; color?: string}> = ({len = 160, draw = 1, color = INK, ...p}) => (
  <g {...T(p)} opacity={(p.o ?? 1) * Math.min(1, draw * 3)}>
    <path d={`M 0 0 L ${len * draw} 0`} fill="none" stroke={color} strokeWidth={10} strokeLinecap="round" />
    {draw > 0.9 && <path d={`M ${len - 26} -24 L ${len} 0 L ${len - 26} 24`} fill="none" stroke={color} strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" />}
  </g>
);

export const Backpack: React.FC<P & {open?: boolean}> = ({open = false, ...p}) => (
  <g {...T(p)}>
    <rect x={-110} y={-130} width={220} height={250} rx={46} fill="#4f7a4a" {...sw(9)} />
    <rect x={-70} y={10} width={140} height={90} rx={18} fill="#3f6b45" {...sw(6)} />
    <path d={open ? 'M -100 -100 Q 0 -190 100 -100 L 90 -70 Q 0 -120 -90 -70 Z' : 'M -100 -100 Q 0 -150 100 -100 L 100 -20 Q 0 -60 -100 -20 Z'} fill="#5f8f58" {...sw(8)} />
    {!open && <rect x={-16} y={-62} width={32} height={30} rx={6} fill={YELLOW} {...sw(5)} />}
  </g>
);

export const Hanger: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x} ${y})`}><path d="M -40 0 L 40 0" {...sw(8)} /></g>
);

/** A generic, species-neutral four-legged animal. */
export const Wildlife: React.FC<P> = (p) => (
  <g {...T(p)}>
    <ellipse cx={0} cy={86} rx={120} ry={14} fill="rgba(0,0,0,0.16)" />
    <path d="M -80 0 Q -90 -60 -30 -70 L 70 -70 Q 120 -60 112 -10 Q 108 30 70 34 L -50 34 Q -86 34 -80 0 Z" fill="#a8744a" {...sw(8)} />
    <path d="M -60 30 L -64 84 M -20 34 L -22 84 M 50 34 L 54 84 M 90 24 L 96 84" fill="none" stroke={INK} strokeWidth={20} strokeLinecap="round" />
    <path d="M -60 30 L -64 84 M -20 34 L -22 84 M 50 34 L 54 84 M 90 24 L 96 84" fill="none" stroke="#a8744a" strokeWidth={9} strokeLinecap="round" />
    <path d="M 90 -50 Q 130 -110 170 -96 Q 214 -80 200 -56 Q 180 -40 130 -30 Z" fill="#a8744a" {...sw(8)} />
    <path d="M 116 -90 L 108 -130 L 134 -100 Z M 150 -100 L 150 -140 L 170 -102 Z" fill="#a8744a" {...sw(6)} />
    <circle cx={160} cy={-78} r={5} fill={INK} />
    <circle cx={206} cy={-62} r={6} fill={INK} />
  </g>
);

export const RescueTeam: React.FC<P> = (p) => (
  <g {...T(p)}>
    {[0, 56, 112].map((dx, i) => (
      <g key={i} transform={`translate(${dx} ${i % 2 === 0 ? 0 : 6})`}>
        <circle cx={0} cy={-64} r={14} fill={WHITE} {...sw(4)} />
        <path d="M -16 -50 L 16 -50 L 18 -10 L -18 -10 Z" fill={ORANGE} {...sw(4)} />
        <path d="M -8 -10 L -10 24 M 8 -10 L 10 24" {...sw(6)} fill="none" />
        <path d="M -16 -76 Q 0 -96 16 -76 Z" fill={RED} {...sw(4)} />
      </g>
    ))}
  </g>
);

export const Cloud: React.FC<P> = (p) => (
  <g {...T(p)}>
    <path d="M -90 30 Q -110 -10 -60 -20 Q -50 -60 0 -50 Q 40 -70 70 -30 Q 120 -30 110 10 Q 120 40 80 40 L -60 40 Q -90 44 -90 30 Z" fill={WHITE} {...sw()} />
  </g>
);

export const Beacon: React.FC<{x: number; y: number; t: number; color?: string}> = ({x, y, t, color = YELLOW}) => (
  <g transform={`translate(${x} ${y})`} fill="none" stroke={color} strokeWidth={8} strokeLinecap="round">
    {[0, 1, 2].map((i) => {
      const k = ((t / 40 + i / 3) % 1);
      return <circle key={i} r={30 + k * 110} opacity={1 - k} />;
    })}
  </g>
);

export const SosMarker: React.FC<P> = (p) => (
  <g {...T(p)}>
    <rect x={-120} y={-34} width={240} height={68} rx={10} fill={SAND} {...sw()} />
    <text y={22} textAnchor="middle" fontFamily={FONT_HAND} fontSize={64} fill={RED} style={{fontWeight: 700}}>S O S</text>
  </g>
);

export const ThoughtBubble: React.FC<{x: number; y: number; s?: number; o?: number; children?: React.ReactNode}> = ({x, y, s = 1, o = 1, children}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <circle cx={-110} cy={110} r={10} fill={WHITE} {...sw(4)} />
    <circle cx={-80} cy={70} r={16} fill={WHITE} {...sw(5)} />
    <path d="M -60 20 Q -100 -60 -20 -70 Q 20 -130 100 -90 Q 190 -100 190 -20 Q 220 40 150 50 Q 100 90 40 50 Q -20 70 -60 20 Z" fill={WHITE} {...sw(6)} />
    {children}
  </g>
);
