import React from 'react';
import {INK, mulberry32, OUT, SAND} from '../theme';

export type BackgroundKind = 'forest' | 'dusk' | 'stream' | 'overhang' | 'home' | 'meadow';

type Palette = {
  skyTop: string; skyBottom: string; far: string; mid: string; ground: string;
  trunk: string; leafA: string; leafB: string; path: string;
};

const PALETTES: Record<'forest' | 'dusk' | 'stream' | 'meadow', Palette> = {
  forest: {skyTop: '#bfe0d0', skyBottom: '#eef5dc', far: '#a9cfa4', mid: '#86b883', ground: '#7fae6f', trunk: '#8a6a45', leafA: '#4f8a52', leafB: '#6fa468', path: '#dcc99b'},
  dusk: {skyTop: '#4d5a86', skyBottom: '#eab38a', far: '#52716f', mid: '#3f5f5c', ground: '#34554a', trunk: '#4a3a2c', leafA: '#2f5249', leafB: '#3a6354', path: '#8d8266'},
  stream: {skyTop: '#bfe0d0', skyBottom: '#f1f6df', far: '#a9cfa4', mid: '#86b883', ground: '#7fae6f', trunk: '#8a6a45', leafA: '#4f8a52', leafB: '#6fa468', path: '#dcc99b'},
  meadow: {skyTop: '#a9d8ec', skyBottom: '#fbefcf', far: '#b9d6a2', mid: '#98c283', ground: '#86b873', trunk: '#8a6a45', leafA: '#5b9a58', leafB: '#7cb066', path: '#e6d3a2'},
};

const Sky: React.FC<{p: Palette; id: string}> = ({p, id}) => (
  <g>
    <defs>
      <linearGradient id={`sky-${id}`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={p.skyTop} />
        <stop offset="1" stopColor={p.skyBottom} />
      </linearGradient>
    </defs>
    <rect x={-200} y={-100} width={2320} height={1280} fill={`url(#sky-${id})`} />
  </g>
);

const Hills: React.FC<{color: string; baseY: number; amp: number; seed: number; shift: number}> = ({color, baseY, amp, seed, shift}) => {
  const rnd = mulberry32(seed);
  const pts: string[] = [];
  const step = 240;
  for (let x = -400; x <= 2400; x += step) pts.push(`${x} ${baseY - rnd() * amp}`);
  let d = `M -400 1200 L ${pts[0]}`;
  for (let i = 1; i < pts.length; i++) {
    const [px, py] = pts[i - 1].split(' ').map(Number);
    const [cx, cy] = pts[i].split(' ').map(Number);
    d += ` Q ${px + step / 2} ${Math.min(py, cy) - 40} ${cx} ${cy}`;
  }
  d += ' L 2400 1200 Z';
  return <path d={d} fill={color} stroke={INK} strokeWidth={5} strokeLinejoin="round" transform={`translate(${shift} 0)`} />;
};

type TreeStyle = 'pine' | 'round';
const Tree: React.FC<{x: number; y: number; s: number; style: TreeStyle; p: Palette; sw: number}> = ({x, y, s, style, p, sw}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-14} y={-120} width={28} height={120} fill={p.trunk} stroke={INK} strokeWidth={sw} strokeLinejoin="round" />
    {style === 'pine' ? (
      <g fill={p.leafA} stroke={INK} strokeWidth={sw} strokeLinejoin="round">
        <path d="M 0 -420 L -80 -250 L 80 -250 Z" />
        <path d="M 0 -340 L -105 -160 L 105 -160 Z" />
        <path d="M 0 -250 L -130 -80 L 130 -80 Z" fill={p.leafB} />
      </g>
    ) : (
      <g fill={p.leafA} stroke={INK} strokeWidth={sw} strokeLinejoin="round">
        <circle cx={0} cy={-230} r={105} />
        <circle cx={-70} cy={-160} r={70} fill={p.leafB} />
        <circle cx={70} cy={-165} r={66} fill={p.leafB} />
      </g>
    )}
  </g>
);

const TreeRow: React.FC<{p: Palette; seed: number; y: number; count: number; scale: number; sw: number; shift: number; skip?: [number, number]}> = ({p, seed, y, count, scale, sw, shift, skip}) => {
  const rnd = mulberry32(seed);
  const items: React.ReactNode[] = [];
  for (let i = 0; i < count; i++) {
    const x = -300 + (i / (count - 1)) * 2520 + (rnd() - 0.5) * 120;
    const s = scale * (0.8 + rnd() * 0.45);
    const style: TreeStyle = rnd() > 0.45 ? 'pine' : 'round';
    if (skip && x > skip[0] && x < skip[1]) continue;
    items.push(<Tree key={i} x={x} y={y + (rnd() - 0.5) * 30} s={s} style={style} p={p} sw={sw} />);
  }
  return <g transform={`translate(${shift} 0)`}>{items}</g>;
};

const Ground: React.FC<{p: Palette; path?: boolean}> = ({p, path = true}) => (
  <g>
    <path d="M -200 800 Q 500 770 1100 800 T 2200 790 L 2200 1200 L -200 1200 Z" fill={p.ground} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    {path && (
      <path d="M 560 1200 Q 820 980 900 880 Q 940 830 980 800 L 1060 800 Q 1020 850 1100 930 Q 1300 1060 1500 1200 Z" fill={p.path} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    )}
    {[[200, 900], [300, 1010], [1550, 930], [1700, 1040], [1380, 870], [120, 1060]].map(([gx, gy], i) => (
      <path key={i} d={`M ${gx} ${gy} l -10 -26 M ${gx} ${gy} l 0 -32 M ${gx} ${gy} l 12 -26`} stroke={INK} strokeWidth={5} strokeLinecap="round" fill="none" />
    ))}
  </g>
);

const Clouds: React.FC<{shift: number}> = ({shift}) => (
  <g transform={`translate(${shift} 0)`} fill="#ffffff" stroke={INK} strokeWidth={5} strokeLinejoin="round">
    <path d="M 220 190 q 20 -50 70 -30 q 30 -40 80 -10 q 50 -10 50 40 q 20 30 -20 40 L 250 230 q -50 -4 -30 -40 Z" />
    <path d="M 1380 130 q 20 -50 70 -30 q 30 -40 80 -10 q 50 -10 50 40 q 20 30 -20 40 L 1410 170 q -50 -4 -30 -40 Z" />
  </g>
);

const Stream: React.FC<{shift: number}> = ({shift}) => (
  <g transform={`translate(${shift} 0)`}>
    <path d="M 700 800 Q 900 840 760 920 Q 560 1010 760 1200 L 1500 1200 Q 1300 1030 1480 930 Q 1620 850 1500 800 Z" fill="#7cc3de" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    {[[900, 900], [1100, 1000], [1250, 940], [820, 1080]].map(([wx, wy], i) => (
      <path key={i} d={`M ${wx} ${wy} q 20 -14 40 0 q 20 14 40 0`} fill="none" stroke="#ffffff" strokeWidth={6} strokeLinecap="round" />
    ))}
    {[[640, 930, 50], [1530, 960, 60], [700, 1110, 46]].map(([rx, ry, rr], i) => (
      <ellipse key={i} cx={rx} cy={ry} rx={rr} ry={rr * 0.62} fill="#b9b3a2" stroke={INK} strokeWidth={6} />
    ))}
    {[[580, 860], [1600, 880]].map(([cx, cy], i) => (
      <g key={i} stroke={INK} strokeWidth={5} strokeLinecap="round" fill="none">
        <path d={`M ${cx} ${cy} l -14 -90`} /><path d={`M ${cx} ${cy} l 4 -100`} /><path d={`M ${cx} ${cy} l 20 -84`} />
      </g>
    ))}
  </g>
);

const Overhang: React.FC = () => (
  <g>
    <rect x={-200} y={-100} width={2320} height={1280} fill="#cfdccb" />
    <path d="M -200 1200 L -200 -100 L 1000 -100 Q 1100 120 900 260 Q 700 330 620 470 Q 560 600 620 800 L 1000 1200 Z" fill="#b8ab94" stroke={INK} strokeWidth={8} strokeLinejoin="round" />
    <path d="M 620 470 Q 760 520 980 470 Q 1040 440 1060 380" fill="none" stroke={INK} strokeWidth={6} strokeLinecap="round" />
    <path d="M -100 300 l 200 40 M 80 520 l 240 -30 M 300 150 l 120 60" stroke="#8d8070" strokeWidth={8} strokeLinecap="round" fill="none" />
    <path d="M 1000 -100 L 2200 -100 L 2200 800 L 1100 800 Q 1000 260 1000 -100 Z" fill="#a9cfa4" stroke={INK} strokeWidth={6} strokeLinejoin="round" opacity={0.9} />
    <path d="M -200 780 Q 600 760 1300 790 T 2200 780 L 2200 1200 L -200 1200 Z" fill="#8ab47b" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    <path d="M 500 1200 L 640 820 Q 1000 780 1500 830 L 1700 1200 Z" fill={SAND} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
  </g>
);

const Home: React.FC = () => (
  <g>
    <rect x={-200} y={-100} width={2320} height={900} fill="#efe3c8" />
    <rect x={-200} y={780} width={2320} height={420} fill="#c9a06c" />
    <path d="M -200 780 L 2200 780" stroke={INK} strokeWidth={8} />
    {[0, 1, 2, 3, 4, 5].map((i) => (
      <path key={i} d={`M ${-200 + i * 480} 780 L ${-300 + i * 560} 1200`} stroke="#a67f4f" strokeWidth={5} />
    ))}
    {/* window onto the forest */}
    <g>
      <rect x={1280} y={140} width={420} height={380} fill="#bfe0d0" stroke={INK} strokeWidth={10} />
      <path d="M 1280 420 Q 1400 360 1500 420 T 1700 400 L 1700 520 L 1280 520 Z" fill="#86b883" stroke={INK} strokeWidth={5} />
      <path d="M 1560 400 L 1520 300 L 1600 300 Z M 1560 340 L 1505 240 L 1615 240 Z" fill="#4f8a52" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      <path d="M 1490 140 L 1490 520 M 1280 330 L 1700 330" stroke={INK} strokeWidth={10} />
    </g>
    {/* shelf with a map frame */}
    <rect x={260} y={170} width={360} height={250} fill="#f8f0d8" stroke={INK} strokeWidth={8} />
    <path d="M 290 360 Q 350 260 420 330 T 590 250" fill="none" stroke={OUT.stroke} strokeWidth={5} strokeDasharray="14 10" />
    <circle cx={590} cy={250} r={10} fill="#d2402f" stroke={INK} strokeWidth={4} />
    {/* table */}
    <rect x={560} y={700} width={800} height={50} rx={10} fill="#a67f4f" stroke={INK} strokeWidth={8} />
    <path d="M 620 750 L 600 1000 M 1300 750 L 1320 1000" stroke={INK} strokeWidth={22} strokeLinecap="round" />
    <path d="M 620 750 L 600 1000 M 1300 750 L 1320 1000" stroke="#a67f4f" strokeWidth={10} strokeLinecap="round" />
  </g>
);

export type BackgroundProps = {kind: BackgroundKind; t?: number};

/** Illustrated background. `t` (0..1) drives a very small parallax drift between layers. */
export const Background: React.FC<BackgroundProps> = ({kind, t = 0}) => {
  const drift = (t - 0.5) * 2; // -1..1
  if (kind === 'home') {
    return <svg width="100%" height="100%" viewBox="0 0 1920 1080" style={{position: 'absolute', inset: 0}}><Home /></svg>;
  }
  if (kind === 'overhang') {
    return <svg width="100%" height="100%" viewBox="0 0 1920 1080" style={{position: 'absolute', inset: 0}}><Overhang /></svg>;
  }
  const p = PALETTES[kind];
  return (
    <svg width="100%" height="100%" viewBox="0 0 1920 1080" style={{position: 'absolute', inset: 0}}>
      <Sky p={p} id={kind} />
      {kind === 'dusk' ? (
        <g>
          <circle cx={1020} cy={250} r={80} fill="#f6d28f" stroke={INK} strokeWidth={6} />
          <g fill="#ffffff" stroke="none">{[[200, 120], [520, 220], [900, 90], [1250, 160], [1720, 110], [60, 300]].map(([sx, sy], i) => <circle key={i} cx={sx} cy={sy} r={3 + (i % 2)} />)}</g>
        </g>
      ) : (
        <Clouds shift={drift * 24} />
      )}
      <Hills color={p.far} baseY={560} amp={110} seed={3} shift={drift * 14} />
      <TreeRow p={p} seed={11} y={640} count={16} scale={0.42} sw={4} shift={drift * 22} />
      <Hills color={p.mid} baseY={690} amp={80} seed={9} shift={drift * 30} />
      <TreeRow p={p} seed={23} y={760} count={11} scale={0.7} sw={5} shift={drift * 44} skip={kind === 'stream' ? [560, 1700] : [700, 1300]} />
      <Ground p={p} path={kind !== 'stream'} />
      {kind === 'stream' && <Stream shift={drift * 10} />}
      <TreeRow p={p} seed={41} y={1030} count={4} scale={1.25} sw={7} shift={drift * 70} skip={[500, 1500]} />
      {kind === 'dusk' && <rect x={0} y={0} width={1920} height={1080} fill="#1b2340" opacity={0.28} />}
    </svg>
  );
};
