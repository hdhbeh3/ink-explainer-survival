import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {FPS, HEIGHT, TOTAL_FRAMES, validateTimeline, WIDTH} from './timeline';

export const COMPOSITION_ID = 'SurvivalInTheWild';

export const Root: React.FC = () => (
  <Composition
    id="SurvivalInTheWild"
    component={Video}
    width={WIDTH}
    height={HEIGHT}
    fps={FPS}
    durationInFrames={TOTAL_FRAMES}
    calculateMetadata={() => {
      const problems = validateTimeline();
      if (problems.length > 0) throw new Error(`Invalid timeline:\n${problems.join('\n')}`);
      return {durationInFrames: TOTAL_FRAMES};
    }}
  />
);
