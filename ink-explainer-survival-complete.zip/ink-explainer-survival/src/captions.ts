export type Caption = {text: string; from: number; to: number};

/** Silence before narration starts inside each scene (frames). */
export const NARRATION_LEAD_IN = 20;
/** Frames kept free at the end of each scene after narration finishes. */
export const NARRATION_TAIL = 90;
const MAX_WORDS = 11;

/** Default speech window when no narration audio has been measured. */
export const defaultSpeechFrames = (sceneFrames: number): number =>
  Math.max(30, sceneFrames - NARRATION_LEAD_IN - NARRATION_TAIL);

/** Split narration into short caption-sized chunks, preferring sentence boundaries. */
export const chunkNarration = (text: string): string[] => {
  const sentences = text.match(/[^.!?]+[.!?]+["']?|[^.!?]+$/g) ?? [text];
  const chunks: string[] = [];
  for (const raw of sentences) {
    const words = raw.trim().split(/\s+/).filter(Boolean);
    if (words.length === 0) continue;
    if (words.length <= MAX_WORDS) {
      chunks.push(words.join(' '));
      continue;
    }
    const parts = Math.ceil(words.length / MAX_WORDS);
    const size = Math.ceil(words.length / parts);
    for (let i = 0; i < words.length; i += size) chunks.push(words.slice(i, i + size).join(' '));
  }
  return chunks;
};

/**
 * Time-aligned captions. Chunk timing is proportional to character count across the speech
 * window (measured narration length when available, otherwise the default window).
 */
export const buildCaptions = (narration: string, speechFrames: number): Caption[] => {
  const chunks = chunkNarration(narration);
  const totalChars = chunks.reduce((n, c) => n + c.length, 0);
  let cursor = NARRATION_LEAD_IN;
  return chunks.map((text, i) => {
    const len = Math.max(12, Math.round((text.length / totalChars) * speechFrames));
    const from = cursor;
    const to = i === chunks.length - 1 ? NARRATION_LEAD_IN + speechFrames : cursor + len;
    cursor = to;
    return {text, from, to};
  });
};
