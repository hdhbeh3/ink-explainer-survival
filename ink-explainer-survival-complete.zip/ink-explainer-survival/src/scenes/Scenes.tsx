import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Alex, type ArmPose, type Expression} from '../art/Alex';
import {Rain} from '../art/Overlays';
import {
  ArrowRight, Backpack, Beacon, Berries, Blanket, Bottle, Cloud, Compass, Filter, FirstAid, Flashlight, Jacket, Label,
  Lighter, MapSheet, Matches, Mirror, Mushroom, Phone, Pot, Ration, RescueTeam, Sign, SosMarker, Tablets, Tarp,
  ThoughtBubble, Whistle, WarningMark, WarningTriangle, Wildlife,
} from '../art/Props';
import {appear, pop, prog, pulse} from '../anim';
import {cueFrame} from '../cues';
import {SceneShell, type SceneProps, win} from '../SceneShell';
import {INK, RED, WHITE, YELLOW} from '../theme';

const cam = (zoom: number, x = 0, y = 0) => ({zoom, x, y});
/** Pick the latest (frame, value) pair whose frame has been reached. */
const pick = <T,>(frame: number, steps: Array<[number, T]>): T => {
  let v = steps[0][1];
  for (const [f, val] of steps) if (frame >= f) v = val;
  return v;
};
const Q: React.FC<{x: number; y: number; o: number; s?: number}> = ({x, y, o, s = 1}) => (
  <text x={x} y={y} fontFamily="'Patrick Hand', cursive" fontSize={120 * s} fill={RED} stroke={INK} strokeWidth={5} opacity={o} textAnchor="middle" style={{fontWeight: 700}}>?</text>
);

/* 1 ─ HOOK */
export const HookScene: React.FC<SceneProps> = ({scene, index}) => {
  const f = useCurrentFrame();
  const c = (p: string) => cueFrame(scene, p);
  const tSudden = c('But suddenly');
  const tPath = c('You do not recognize the path');
  const tPhone = c('Your phone has no signal');
  const tLost = c('You are lost in the wilderness');
  const tWhat = c('What would you do?');
  const expression: Expression = pick<Expression>(f, [[0, 'happy'], [tSudden, 'surprised'], [tPhone, 'worried']]);
  const arms: ArmPose = pick<ArmPose>(f, [[0, 'down'], [tPhone, 'hold'], [tLost, 'wide']]);
  return (
    <SceneShell scene={scene} index={index} from={cam(1.14, 0, 20)} to={cam(1.0)}>
      <Alex x={760} y={885} scale={1.15} expression={expression} arms={arms}>
        {f >= tPhone && f < tLost + 40 && <Phone x={0} y={-215} s={0.8 * pop(f, tPhone)} />}
      </Alex>
      <Q x={640} y={400} o={appear(f, tPath)} />
      <Q x={870} y={360} o={appear(f, tPath + 14)} s={0.8} />
      <Q x={760} y={290} o={appear(f, tPath + 26)} s={1.1} />
      <Label x={1340} y={430} text="NO SIGNAL" o={appear(f, tPhone) * win(f, tPhone, tLost + 60)} size={56} color="#ffe3de" />
      <Label x={1340} y={560} text="LOST IN THE WILD" o={appear(f, tLost) * win(f, tLost, tWhat + 20)} size={56} color={WHITE} />
      <Label x={1340} y={480} text="What would you do?" o={appear(f, tWhat)} size={70} color={YELLOW} s={1 + 0.03 * pulse(f, 40)} />
    </SceneShell>
  );
};

/* 2 ─ STAY CALM */
export const CalmScene: React.FC<SceneProps> = ({scene, index}) => {
  const f = useCurrentFrame();
  const c = (p: string) => cueFrame(scene, p);
  const tBreath = c('Take a deep breath');
  const tThink = c('Think about where you came from');
  const tObs = c('Observe the surroundings');
  const tSupply = c('Check your supplies');
  const tWord = c('Remember the word STOP');
  const tRand = c('Moving randomly');
  const expression: Expression = pick<Expression>(f, [[0, 'worried'], [tBreath, 'calm'], [tThink, 'thinking'], [tObs, 'calm'], [tSupply, 'determined'], [tRand, 'worried']]);
  const arms: ArmPose = pick<ArmPose>(f, [[0, 'shield'], [tBreath, 'wide'], [tThink, 'chin'], [tObs, 'wide'], [tSupply, 'hold'], [tRand, 'down']]);
  const words = ['STOP', 'THINK', 'OBSERVE', 'PLAN'];
  const t0 = c('Stop, Think, Observe, Plan');
  return (
    <SceneShell scene={scene} index={index} from={cam(1.0, 0, 0)} to={cam(1.12, -40, 10)}>
      <Alex x={560} y={885} scale={1.2} expression={expression} arms={arms} />
      <ThoughtBubble x={720} y={380} s={pop(f, tThink) * 0.9} o={win(f, tThink, tObs, 8)}>
        <path d="M 20 -10 Q 60 -50 100 -10 M 20 10 L 100 10" fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round" transform="translate(0 -10)" />
      </ThoughtBubble>
      <g opacity={appear(f, tBreath, 12) * win(f, tBreath, tThink, 12)}>
        <path d="M 760 560 q 40 -30 80 0 q 40 30 80 0" fill="none" stroke="#ffffff" strokeWidth={10} strokeLinecap="round" />
        <Label x={850} y={640} text="breathe" size={46} />
      </g>
      {words.map((w, i) => {
        const at = t0 + i * 48;
        const k = pop(f, at, 14);
        return (
          <g key={w} transform={`translate(1450 ${290 + i * 150}) scale(${k})`} opacity={Math.min(1, k)}>
            <rect x={-250} y={-58} width={500} height={116} rx={20} fill={i === 0 ? RED : WHITE} stroke={INK} strokeWidth={8} />
            <text x={0} y={26} textAnchor="middle" fontFamily="'Patrick Hand', cursive" fontSize={84} fill={i === 0 ? WHITE : INK} style={{fontWeight: 700}}>{w}</text>
          </g>
        );
      })}
      {/* random wandering path, crossed out */}
      <g opacity={appear(f, tRand, 14)}>
        <path d="M 900 760 q 80 -90 150 -10 t 150 -20 q 60 -60 100 10" fill="none" stroke={INK} strokeWidth={9} strokeDasharray="4 18" strokeLinecap="round" />
        <WarningMark x={1090} y={730} draw={prog(f, tRand, tRand + 30)} s={0.9} />
      </g>
    </SceneShell>
  );
};

/* 3 ─ SHELTER */
export const ShelterScene: React.FC<SceneProps> = ({scene, index}) => {
  const f = useCurrentFrame();
  const c = (p: string) => cueFrame(scene, p);
  const tRain = c('Rain, wind');
  const tSafe = c('Look for a safe place');
  const tTarp = c('A tarp or emergency blanket');
  const tAvoid = c('Avoid dry riverbeds');
  const tEnd = c('A shelter does not need to look beautiful');
  const expression: Expression = pick<Expression>(f, [[0, 'worried'], [tSafe, 'thinking'], [tTarp, 'calm'], [tAvoid, 'determined'], [tEnd, 'happy']]);
  const arms: ArmPose = pick<ArmPose>(f, [[0, 'shield'], [tSafe, 'chin'], [tTarp, 'point'], [tAvoid, 'wide'], [tEnd, 'down']]);
  const avoid = ['DRY RIVERBED', 'UNSTABLE SLOPE', 'DEAD BRANCHES', 'FLOOD RISK'];
  const rainI = appear(f, tRain, 40) * (f > tSafe ? 0.7 : 1);
  return (
    <SceneShell scene={scene} index={index} from={cam(1.0, 30, 0)} to={cam(1.1, -30, 0)} overlay={rainI > 0.02 ? <Rain intensity={rainI} /> : null}>
      <Alex x={420} y={885} scale={1.15} expression={expression} arms={arms} />
      <Label x={560} y={300} text="NATURAL OVERHANG" size={46} o={appear(f, tSafe) * win(f, tSafe, tAvoid, 12)} />
      <g opacity={win(f, tTarp, tAvoid, 12)}>
        <g transform={`translate(${1250 + (1 - appear(f, tTarp, 20)) * 400} 0)`}>
          <Tarp x={0} y={600} s={1.3} />
          <Label x={0} y={790} text="TARP" size={42} />
        </g>
        <g transform={`translate(${1640 + (1 - appear(f, tTarp + 20, 20)) * 400} 0)`}>
          <Blanket x={0} y={650} s={1.2} />
          <Label x={0} y={790} text="EMERGENCY BLANKET" size={34} />
        </g>
      </g>
      {avoid.map((a, i) => {
        const k = appear(f, tAvoid + i * 24, 12);
        return (
          <g key={a} opacity={k * win(f, tAvoid, tEnd, 12)}>
            <Sign x={1450} y={330 + i * 120} text={a} w={360} />
            <WarningMark x={1210} y={330 + i * 120} s={0.45} draw={prog(f, tAvoid + i * 24, tAvoid + i * 24 + 20)} />
          </g>
        );
      })}
      <g opacity={appear(f, tEnd, 16)}>
        <Label x={1350} y={480} text="Protect your body." size={64} color={YELLOW} />
        <Label x={1350} y={580} text="Conserve energy." size={64} color={WHITE} />
      </g>
    </SceneShell>
  );
};

/* 4 ─ WATER */
export const WaterScene: React.FC<SceneProps> = ({scene, index}) => {
  const f = useCurrentFrame();
  const c = (p: string) => cueFrame(scene, p);
  const tClear = c('Clear-looking water');
  const tMicro = c('Natural water may contain');
  const tFilter = c('proper water filter');
  const tTab = c('approved purification tablets');
  const tBoil = c('boil water');
  const tChem = c('Boiling does not remove chemical contamination');
  const tNever = c('Never assume');
  const expression: Expression = pick<Expression>(f, [[0, 'calm'], [tMicro, 'worried'], [tFilter, 'thinking'], [tChem, 'worried'], [tNever, 'determined']]);
  const arms: ArmPose = pick<ArmPose>(f, [[0, 'down'], [tFilter, 'point'], [tChem, 'shield'], [tNever, 'wide']]);
  return (
    <SceneShell scene={scene} index={index} from={cam(1.12, 60, 0)} to={cam(1.0, -20, 0)}>
      <Alex x={430} y={885} scale={1.15} expression={expression} arms={arms} />
      <g opacity={appear(f, tClear - 20, 16)}>
        <rect x={930} y={110} width={930} height={470} rx={26} fill="#fbf7e6" stroke={INK} strokeWidth={8} />
      </g>
      <g opacity={appear(f, tClear, 14)} transform={`scale(${1})`}>
        <Bottle x={1055} y={320} s={1.3} fill="#9dd6e6" />
        <Label x={1055} y={470} text="DOUBTFUL WATER" size={26} />
        {/* germs */}
        {f >= tMicro && [[1040, 330], [1070, 360], [1060, 305]].map(([gx, gy], i) => (
          <g key={i} transform={`translate(${gx} ${gy}) scale(${pop(f, tMicro + i * 6)})`}>
            <circle r={9} fill="#9b4fb0" stroke={INK} strokeWidth={3} />
            <path d="M 0 -9 L 0 -15 M 9 0 L 15 0 M 0 9 L 0 15 M -9 0 L -15 0" stroke={INK} strokeWidth={3} strokeLinecap="round" />
          </g>
        ))}
      </g>
      <g opacity={appear(f, tFilter, 14)}>
        <Filter x={1285} y={330} s={1.0} />
        <Label x={1285} y={470} text="FILTER" size={32} />
      </g>
      <g opacity={appear(f, tTab, 14)}>
        <Tablets x={1515} y={330} s={1.4} />
        <Label x={1515} y={470} text="TABLETS" size={32} />
      </g>
      <g opacity={appear(f, tBoil, 14)}>
        <Pot x={1745} y={340} s={0.95} steam={f} />
        <Label x={1745} y={470} text="BOIL" size={32} />
      </g>
      {[1400, 1630].map((ox, i) => (
        <text key={ox} x={ox} y={350} textAnchor="middle" fontFamily="'Patrick Hand', cursive" fontSize={36} fill={INK} opacity={appear(f, tFilter + i * 60 + 20)}>OR</text>
      ))}
      <g opacity={appear(f, tChem, 10)}>
        <WarningMark x={1745} y={340} s={1.2} draw={prog(f, tChem, tChem + 24)} />
        <Label x={1500} y={540} text="BOILING ≠ CHEMICAL-SAFE" size={36} color="#ffe3de" />
      </g>
      <g opacity={appear(f, tNever, 12)}>
        <WarningMark x={1150} y={940} s={0.8} draw={prog(f, tNever, tNever + 24)} />
        <Label x={1330} y={1000} text="Not automatically safe" size={46} />
      </g>
    </SceneShell>
  );
};

/* 5 ─ WARMTH */
export const WarmthScene: React.FC<SceneProps> = ({scene, index}) => {
  const f = useCurrentFrame();
  const c = (p: string) => cueFrame(scene, p);
  const tFire = c('Fire can provide warmth');
  const tFood = c('prepare food');
  const tAtt = c('attract attention');
  const tRisk = c('but it also comes with serious risks');
  const tMist = c('A small mistake');
  const tCons = c('Consider weather');
  const tNever = c('Never light a fire');
  const tWarm = c('Warm clothing');
  const expression: Expression = pick<Expression>(f, [[0, 'worried'], [tRisk, 'surprised'], [tCons, 'thinking'], [tNever, 'determined'], [tWarm, 'calm']]);
  const arms: ArmPose = pick<ArmPose>(f, [[0, 'chin'], [tRisk, 'shield'], [tCons, 'chin'], [tNever, 'shield'], [tWarm, 'hold']]);
  const reasons: Array<[string, number]> = [['WARMTH', tFire], ['COOKING', tFood], ['ATTENTION', tAtt]];
  const checks: Array<[string, number]> = [['WEATHER', tCons], ['VEGETATION', tCons + 40], ['LOCAL RULES', tCons + 80]];
  return (
    <SceneShell scene={scene} index={index} from={cam(1.0, 0, 0)} to={cam(1.1, -50, 0)}>
      <Alex x={640} y={885} scale={1.15} expression={expression} arms={arms} />
      <g opacity={win(f, tFire, tRisk, 12)}>
        <Lighter x={1680} y={540} s={1.2} />
        <Matches x={1680} y={700} s={1.2} />
        {reasons.map(([t, at]) => (
          <g key={t} opacity={appear(f, at, 12)}>
            <Sign x={1380} y={360 + reasons.findIndex((r) => r[0] === t) * 120} text={t} w={300} color={YELLOW} />
          </g>
        ))}
      </g>
      <g opacity={win(f, tRisk, tCons, 12)} transform={`translate(1450 480) scale(${1.7 * pop(f, tRisk)})`}>
        <WarningTriangle />
      </g>
      <Label x={1450} y={700} text="A SMALL MISTAKE = WILDFIRE" size={40} o={appear(f, tMist) * win(f, tMist, tCons, 12)} color="#ffe3de" />
      {checks.map(([t, at], i) => (
        <g key={t} opacity={appear(f, at, 12) * win(f, tCons, tNever, 12)}>
          <Sign x={1450} y={340 + i * 130} text={t} w={340} />
        </g>
      ))}
      <g opacity={win(f, tNever, tWarm, 12)}>
        <Lighter x={1450} y={520} s={2.2} />
        <WarningMark x={1450} y={520} s={1.7} draw={prog(f, tNever, tNever + 30)} />
        <Label x={1450} y={760} text="UNSAFE = NO FIRE" size={50} color="#ffe3de" />
      </g>
      <g opacity={appear(f, tWarm, 14)}>
        <Jacket x={1320} y={520} s={1.7 * pop(f, tWarm)} />
        <Blanket x={1660} y={540} s={1.5 * pop(f, tWarm + 24)} />
        <Label x={1320} y={700} text="WARM CLOTHING" size={36} />
        <Label x={1660} y={700} text="BLANKET" size={36} />
      </g>
    </SceneShell>
  );
};

/* 6 ─ FOOD */
export const FoodScene: React.FC<SceneProps> = ({scene, index}) => {
  const f = useCurrentFrame();
  const c = (p: string) => cueFrame(scene, p);
  const tPlants = c('The wilderness contains plants');
  const tEdible = c('Some are edible');
  const tAnimal = c('Never eat a wild plant');
  const tFamiliar = c('Never assume a berry');
  const tIdent = c('If you cannot identify it');
  const tSafe = c('Emergency food supplies');
  const expression: Expression = pick<Expression>(f, [[0, 'thinking'], [tEdible, 'worried'], [tIdent, 'determined'], [tSafe, 'happy']]);
  const arms: ArmPose = pick<ArmPose>(f, [[0, 'chin'], [tAnimal, 'wide'], [tIdent, 'shield'], [tSafe, 'hold']]);
  const unknown = 1 - appear(f, tSafe, 16);
  return (
    <SceneShell scene={scene} index={index} from={cam(1.1, 40, 0)} to={cam(1.0, -10, 0)}>
      <Alex x={520} y={885} scale={1.15} expression={expression} arms={arms}>
        {f >= tSafe && <Ration x={0} y={-232} s={0.55 * pop(f, tSafe)} />}
      </Alex>
      <g opacity={unknown}>
        <Berries x={1130} y={620} s={1.9 * pop(f, tPlants)} />
        <Mushroom x={1520} y={640} s={1.6 * pop(f, tPlants + 18)} />
        <Label x={1130} y={800} text="UNKNOWN BERRIES" size={34} o={appear(f, tEdible)} />
        <Label x={1520} y={800} text="UNKNOWN MUSHROOM" size={34} o={appear(f, tEdible + 10)} />
        <WarningMark x={1130} y={560} s={1.4} draw={prog(f, tAnimal, tAnimal + 30)} />
        <WarningMark x={1520} y={560} s={1.4} draw={prog(f, tFamiliar, tFamiliar + 30)} />
        <Label x={1330} y={300} text="NOT SURE? DON'T EAT IT." size={58} color={YELLOW} o={appear(f, tIdent, 14)} />
      </g>
      <g opacity={appear(f, tSafe, 16)}>
        <Backpack x={1300} y={660} s={1.3} open />
        <Ration x={1300} y={470} s={1.6 * pop(f, tSafe + 10)} />
        <Label x={1300} y={880} text="EMERGENCY FOOD = SAFER" size={46} />
      </g>
    </SceneShell>
  );
};

/* 7 ─ SIGNAL */
export const SignalScene: React.FC<SceneProps> = ({scene, index}) => {
  const f = useCurrentFrame();
  const c = (p: string) => cueFrame(scene, p);
  const tPhone = c('If you have a working phone');
  const tLoc = c('Share your location');
  const tSig = c('If you cannot contact anyone');
  const tWhistle = c('A whistle can attract attention');
  const tThree = c('Three repeated whistle blasts');
  const tLight = c('A flashlight or reflective object');
  const tStay = c('Stay in a safe, visible place');
  const expression: Expression = pick<Expression>(f, [[0, 'worried'], [tPhone, 'thinking'], [tSig, 'determined'], [tWhistle, 'calm'], [tStay, 'happy']]);
  const arms: ArmPose = pick<ArmPose>(f, [[0, 'hold'], [tSig, 'down'], [tWhistle, 'up'], [tLight, 'point'], [tStay, 'down']]);
  const needle = Math.sin(f / 9) * 10 + 25;
  return (
    <SceneShell scene={scene} index={index} from={cam(1.0, 70, 0)} to={cam(1.1, -50, 0)}>
      <Alex x={430} y={885} scale={1.15} expression={expression} arms={arms}>
        {f >= tPhone && f < tSig && <Phone x={0} y={-215} s={0.8} noSignal={f < tPhone + 30} />}
      </Alex>
      <g opacity={appear(f, tPhone, 14)}>
        <Phone x={1100} y={400} s={1.3 * pop(f, tPhone)} noSignal={false} />
        <Label x={1100} y={540} text="CALL EMERGENCY" size={30} />
      </g>
      <g opacity={appear(f, tLoc, 14)}>
        <MapSheet x={1420} y={400} s={1.0 * pop(f, tLoc)} />
        <Compass x={1710} y={400} s={1.1 * pop(f, tLoc + 12)} needle={needle} />
        <Label x={1560} y={540} text="SHARE LOCATION / GPS" size={30} />
      </g>
      <g opacity={appear(f, tWhistle, 14)}>
        <Whistle x={1100} y={710} s={1.2 * pop(f, tWhistle)} />
        <Label x={1100} y={830} text="WHISTLE" size={30} />
        {f >= tThree && <Beacon x={1100} y={710} t={f} color={YELLOW} />}
        <Label x={1100} y={610} text="3 BLASTS" size={40} o={appear(f, tThree)} color={YELLOW} />
      </g>
      <g opacity={appear(f, tLight, 14)}>
        <Flashlight x={1420} y={700} s={1.1 * pop(f, tLight)} beam />
        <Mirror x={1710} y={690} s={0.9 * pop(f, tLight + 14)} glint={pulse(f, 30)} />
        <Label x={1560} y={830} text="LIGHT / REFLECTION" size={30} />
      </g>
      <g opacity={appear(f, tStay, 14)}>
        <SosMarker x={820} y={860} s={0.8} />
      </g>
    </SceneShell>
  );
};

/* 8 ─ WILDLIFE */
export const WildlifeScene: React.FC<SceneProps> = ({scene, index}) => {
  const f = useCurrentFrame();
  const c = (p: string) => cueFrame(scene, p);
  const tHome = c('The wilderness is home');
  const tSpace = c('Respect their space');
  const tNever = c('Never approach');
  const tEnc = c('If you encounter a potentially dangerous animal');
  const tDep = c('The correct response depends');
  const tLearn = c('Learn about local wildlife');
  const expression: Expression = pick<Expression>(f, [[0, 'calm'], [tNever, 'determined'], [tEnc, 'surprised'], [tDep, 'thinking'], [tLearn, 'happy']]);
  const arms: ArmPose = pick<ArmPose>(f, [[0, 'down'], [tNever, 'shield'], [tEnc, 'shield'], [tDep, 'chin'], [tLearn, 'point']]);
  const dont: Array<[string, number]> = [["DON'T APPROACH", c('Never approach')], ["DON'T FEED", c('feed,')], ["DON'T CHASE", c('chase,')], ["DON'T PROVOKE", c('provoke')]];
  return (
    <SceneShell scene={scene} index={index} from={cam(1.2, 80, 20)} to={cam(1.0, 0, 0)}>
      <Alex x={430} y={885} scale={1.15} expression={expression} arms={arms} />
      <g opacity={appear(f, tHome, 24)} transform={`translate(${(1 - appear(f, tHome, 24)) * 160} 0)`}>
        <Wildlife x={1380} y={800} s={0.95} />
      </g>
      <g opacity={appear(f, tSpace, 16)}>
        <path d="M 700 855 L 1060 855" stroke={INK} strokeWidth={8} strokeDasharray="22 14" strokeLinecap="round" />
        <ArrowRight x={700} y={855} len={360} draw={1} />
        <Label x={880} y={790} text="SAFE DISTANCE" size={44} color={YELLOW} />
      </g>
      {dont.map(([t, at], i) => (
        <g key={t} opacity={appear(f, at, 12) * win(f, tNever, tEnc, 14)}>
          <Sign x={560 + i * 360} y={210} text={t} w={330} />
          <WarningMark x={560 + i * 360} y={330} s={0.45} draw={prog(f, at, at + 20)} />
        </g>
      ))}
      <Label x={1380} y={330} text="NO SUDDEN MOVES" size={46} o={appear(f, tEnc + 40) * win(f, tEnc, tDep, 14)} />
      <Label x={1380} y={430} text="DON'T RUN BLINDLY" size={46} o={appear(f, tEnc + 90) * win(f, tEnc, tDep, 14)} />
      <g opacity={appear(f, tDep, 14) * win(f, tDep, tLearn, 14)} transform={`translate(1380 380) scale(${1.4 * pop(f, tDep)})`}>
        <WarningTriangle />
      </g>
      <Label x={1380} y={520} text="DEPENDS ON SPECIES" size={44} o={appear(f, tDep + 10) * win(f, tDep, tLearn, 14)} />
      <Label x={1200} y={300} text="LEARN LOCAL WILDLIFE" size={50} color={YELLOW} o={appear(f, tLearn)} />
    </SceneShell>
  );
};

/* 9 ─ KIT */
export const KitScene: React.FC<SceneProps> = ({scene, index}) => {
  const f = useCurrentFrame();
  const c = (p: string) => cueFrame(scene, p);
  const tPack = c('A well-prepared backpack');
  const tTell = c('Tell someone your route');
  const expression: Expression = f >= tTell ? 'determined' : 'happy';
  const arms: ArmPose = f >= tTell ? 'point' : 'down';
  type Item = {phrase: string; x: number; y: number; label: string; node: (s: number) => React.ReactNode};
  const items: Item[] = [
    {phrase: 'drinking water', x: 480, y: 320, label: 'WATER', node: (s) => <Bottle s={0.9 * s} />},
    {phrase: 'a way to treat additional water', x: 690, y: 330, label: 'WATER TREATMENT', node: (s) => <Filter s={0.75 * s} />},
    {phrase: 'first-aid kit', x: 900, y: 310, label: 'FIRST AID', node: (s) => <FirstAid s={1.0 * s} />},
    {phrase: 'navigation tools', x: 1110, y: 330, label: 'NAVIGATION', node: (s) => <MapSheet s={0.75 * s} />},
    {phrase: 'a flashlight', x: 540, y: 580, label: 'FLASHLIGHT', node: (s) => <Flashlight s={0.85 * s} />},
    {phrase: 'a whistle', x: 740, y: 590, label: 'WHISTLE', node: (s) => <Whistle s={0.85 * s} />},
    {phrase: 'emergency shelter', x: 330, y: 570, label: 'SHELTER', node: (s) => <Tarp s={0.5 * s} />},
    {phrase: 'extra clothing', x: 1230, y: 590, label: 'CLOTHING', node: (s) => <Jacket s={0.85 * s} />},
    {phrase: 'appropriate food', x: 1410, y: 610, label: 'FOOD', node: (s) => <Ration s={0.9 * s} />},
    {phrase: 'Keep your phone charged', x: 1380, y: 330, label: 'PHONE + BACKUP POWER', node: (s) => <Phone s={0.8 * s} noSignal={false} />},
  ];
  return (
    <SceneShell scene={scene} index={index} from={cam(1.0, 0, 0)} to={cam(1.05, 0, -10)}>
      <Backpack x={960} y={560} s={1.0} open={f >= tPack + 10} />
      {items.map((it) => {
        const at = c(it.phrase);
        const k = pop(f, at, 16);
        const fly = 1 - appear(f, at, 16);
        return (
          <g key={it.phrase} opacity={Math.min(1, k)}>
            <g transform={`translate(${it.x + (960 - it.x) * fly * 0.6} ${it.y + (520 - it.y) * fly * 0.6})`}>{it.node(k)}</g>
            <Label x={it.x} y={it.y + 110} text={it.label} size={26} o={appear(f, at + 8, 10)} />
          </g>
        );
      })}
      <Alex x={1740} y={900} scale={1.0} flip expression={expression} arms={arms} />
      <Label x={960} y={150} text="TELL SOMEONE: ROUTE + RETURN TIME" size={52} color={YELLOW} o={appear(f, tTell, 14)} />
    </SceneShell>
  );
};

/* 10 ─ ENDING */
export const EndingScene: React.FC<SceneProps> = ({scene, index}) => {
  const f = useCurrentFrame();
  const c = (p: string) => cueFrame(scene, p);
  const tHear = c('Eventually, Alex hears');
  const tTeam = c('A rescue team is approaching');
  const tWhistle = c('He uses his whistle');
  const tLesson = c('This story teaches us');
  const tCard = c('Prepare properly');
  const expression: Expression = pick<Expression>(f, [[0, 'calm'], [tHear, 'surprised'], [tWhistle, 'determined'], [tLesson, 'happy']]);
  const arms: ArmPose = pick<ArmPose>(f, [[0, 'down'], [tHear, 'shield'], [tWhistle, 'up'], [tLesson, 'cheer']]);
  const ax = 620; const ay = 885; const sc = 1.15;
  const lines = ['STAY CALM.', 'STAY PREPARED.', 'STAY SAFE.'];
  const cardK = pop(f, tCard, 20);
  return (
    <SceneShell scene={scene} index={index} from={cam(1.2, 0, 10)} to={cam(1.0, 0, 0)}>
      <g opacity={appear(f, tTeam, 30)} transform={`translate(${(1 - appear(f, tTeam, 60)) * 140} 0)`}>
        <RescueTeam x={1480} y={790} s={0.9} />
      </g>
      <Cloud x={1200} y={300} s={1.2} />
      <Alex x={ax} y={ay} scale={sc} expression={expression} arms={arms} />
      {f >= tWhistle && f < tCard && (
        <g>
          <Whistle x={ax + 98 * sc} y={ay - 425 * sc - 30} s={0.6} />
          <Beacon x={ax + 98 * sc} y={ay - 425 * sc - 30} t={f} />
        </g>
      )}
      <Q x={ax - 120} y={ay - 560} o={win(f, tHear, tTeam, 10)} s={0.7} />
      <g opacity={Math.min(1, cardK)} transform={`translate(1310 ${440}) scale(${0.8 * cardK})`}>
        <rect x={-640} y={-210} width={1280} height={420} rx={30} fill={WHITE} stroke={INK} strokeWidth={10} />
        {lines.map((l, i) => (
          <text key={l} x={0} y={-70 + i * 120} textAnchor="middle" fontFamily="'Patrick Hand', cursive" fontSize={110} fill={i === 2 ? '#2f7a45' : INK} opacity={appear(f, tCard + 6 + i * 44, 14)} style={{fontWeight: 700}}>{l}</text>
        ))}
      </g>
    </SceneShell>
  );
};

export const SCENE_COMPONENTS: Record<string, React.FC<SceneProps>> = {
  hook: HookScene,
  calm: CalmScene,
  shelter: ShelterScene,
  water: WaterScene,
  warmth: WarmthScene,
  food: FoodScene,
  signal: SignalScene,
  wildlife: WildlifeScene,
  kit: KitScene,
  ending: EndingScene,
};
