import React from 'react';
import {AbsoluteFill, Series} from 'remotion';
import {AudioLayer} from './AudioLayer';
import {SCENE_COMPONENTS} from './scenes/Scenes';
import {PAPER} from './theme';
import {scenes} from './timeline';

export const Video: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: PAPER}}>
    <Series>
      {scenes.map((scene, index) => {
        const SceneComponent = SCENE_COMPONENTS[scene.id];
        return (
          <Series.Sequence key={scene.id} durationInFrames={scene.duration}>
            <SceneComponent scene={scene} index={index} />
          </Series.Sequence>
        );
      })}
    </Series>
    <AudioLayer />
  </AbsoluteFill>
);
