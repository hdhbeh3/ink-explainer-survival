import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/google-fonts/PatrickHand';
import {Background} from './art/Background';
import {Camera, type CamState, Stage, Vignette} from './art/Overlays';
import {prog} from './anim';
import {Subtitles} from './Subtitles';
import {FONT_HAND, INK, WHITE} from './theme';
import type {Scene} from './timeline';

loadFont();

export type SceneProps = {scene: Scene; index: number};

type ShellProps = SceneProps & {
  from: CamState;
  to: CamState;
  /** Extra full-frame layers drawn inside the camera but above the stage (e.g. rain). */
  overlay?: React.ReactNode;
  children: React.ReactNode;
};

/** Shared frame for every scene: background, camera, chapter tag, subtitles and transitions. */
export const SceneShell: React.FC<ShellProps> = ({scene, index, from, to, overlay, children}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const inK = prog(frame, 0, 20);
  const outK = prog(frame, durationInFrames - 14, durationInFrames);
  const wipe = index % 2 === 1;
  const eased = 1 - Math.pow(1 - inK, 3);
  const opacity = (wipe ? 1 : inK) * (1 - outK);
  const clip = wipe ? `inset(0 ${(1 - eased) * 100}% 0 0)` : undefined;
  const tagOpacity = interpolate(frame, [12, 30, 120, 150], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  return (
    <AbsoluteFill style={{opacity, clipPath: clip, overflow: 'hidden'}}>
      <Camera from={from} to={to}>
        <Background kind={scene.background} t={frame / Math.max(1, durationInFrames)} />
        <Stage>{children}</Stage>
        {overlay}
      </Camera>
      <Vignette />
      <AbsoluteFill style={{opacity: tagOpacity}}>
        <div
          style={{
            position: 'absolute', top: 54, left: 70, padding: '10px 28px', background: WHITE,
            border: `5px solid ${INK}`, borderRadius: 14, fontFamily: FONT_HAND, fontSize: 44, color: INK,
            boxShadow: '6px 7px 0 rgba(28,36,29,0.25)',
          }}
        >
          {index + 1}. {scene.title}
        </div>
      </AbsoluteFill>
      <Subtitles scene={scene} />
    </AbsoluteFill>
  );
};

/** Opacity window helper: fades in at `a`, fades out at `b`. */
export const win = (frame: number, a: number, b: number, fade = 10): number =>
  interpolate(frame, [a, a + fade, b - fade, b], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
