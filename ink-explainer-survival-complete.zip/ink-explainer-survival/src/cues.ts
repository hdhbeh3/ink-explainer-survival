import manifestJson from './audio-manifest.json';
import {defaultSpeechFrames, NARRATION_LEAD_IN} from './captions';
import type {Scene} from './timeline';

export type NarrationManifest = {
  /** Optional single narration track covering the whole film (public/ relative path). */
  fullTrack?: string | null;
  /** Per-scene narration clips, written by `npm run narration`. */
  narration: Record<string, {file: string; speechFrames: number}>;
};

export const manifest = manifestJson as NarrationManifest;

export const hasSceneNarration = (id: string): boolean => Boolean(manifest.narration[id]);

/** Length of the spoken part of a scene in frames (measured if audio exists, else a default window). */
export const speechFramesFor = (scene: Scene): number => {
  const m = manifest.narration[scene.id];
  return m && m.speechFrames > 0 ? m.speechFrames : defaultSpeechFrames(scene.duration);
};

/** Scene-relative frame at which the narration reaches `phrase` (visual + SFX sync). */
export const cueFrame = (scene: Scene, phrase: string): number => {
  const idx = scene.narration.indexOf(phrase);
  if (idx < 0) return NARRATION_LEAD_IN;
  return Math.round(NARRATION_LEAD_IN + (idx / scene.narration.length) * speechFramesFor(scene));
};
