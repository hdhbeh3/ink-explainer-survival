import type {BackgroundKind} from './art/Background';

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const MIN_SECONDS = 8 * 60;
export const MAX_SECONDS = 10 * 60;

export type SfxName = 'pop' | 'whoosh' | 'whistle' | 'ding' | 'warning' | 'rain' | 'birds';
/** A sound effect cue, fired when the narration reaches `phrase` (exact substring of the scene narration). */
export type SfxCue = {name: SfxName; phrase: string; volume: number};

export type SceneDef = {
  id: string;
  title: string;
  duration: number; // frames @ 30fps
  narration: string;
  visual: string;
  motion: string;
  background: BackgroundKind;
  sfx: SfxCue[];
};

export type Scene = SceneDef & {start: number};

const defs: SceneDef[] = [
  {
    id: 'hook', title: 'The Hook', duration: 1740,
    narration: 'Imagine this. You are walking through a beautiful forest. The birds are singing, the trees are moving gently in the wind, and everything seems peaceful. But suddenly, you realize something terrifying. You do not recognize the path anymore. Your phone has no signal. You are lost in the wilderness. What would you do? Survival is not just about strength. It is about making the right decisions at the right time.',
    visual: 'Alex, a simple ink-style explorer with a backpack, stands on a forest trail. Establish a wide forest background.',
    motion: 'Static character pose; slow camera push-out; subtle parallax in background only.',
    background: 'forest',
    sfx: [{name: 'birds', phrase: 'The birds are singing', volume: 0.5}, {name: 'warning', phrase: 'But suddenly', volume: 0.35}, {name: 'pop', phrase: 'Your phone has no signal', volume: 0.5}, {name: 'ding', phrase: 'It is about making the right decisions', volume: 0.35}],
  },
  {
    id: 'calm', title: 'Stay Calm', duration: 1500,
    narration: 'The first survival skill is controlling your panic. Stop moving for a moment. Take a deep breath and look around. Think about where you came from. Observe the surroundings. Check your supplies and decide what to do next. Remember the word STOP: Stop, Think, Observe, Plan. Moving randomly wastes energy and can make it harder for rescuers to find you.',
    visual: 'Alex in three held poses: worried, thinking, calm. Large STOP / THINK / OBSERVE / PLAN graphic.',
    motion: 'Hold poses; swap expression layers; gentle camera push-in; words appear one at a time.',
    background: 'forest',
    sfx: [{name: 'pop', phrase: 'Stop moving for a moment', volume: 0.5}, {name: 'pop', phrase: 'Take a deep breath', volume: 0.5}, {name: 'pop', phrase: 'Think about where you came from', volume: 0.5}, {name: 'pop', phrase: 'Check your supplies', volume: 0.5}, {name: 'ding', phrase: 'Stop, Think, Observe, Plan', volume: 0.4}],
  },
  {
    id: 'shelter', title: 'Find or Create Shelter', duration: 1680,
    narration: 'Your next priority is protection from the environment. Rain, wind, extreme heat, and cold can become serious threats. Look for a safe place that protects you from the weather. A tarp or emergency blanket can help create protection. Avoid dry riverbeds, unstable slopes, dead branches, and places at risk of flooding. A shelter does not need to look beautiful. It needs to protect your body and conserve energy.',
    visual: 'Three clean illustrated shelter examples: natural overhang, tarp shelter, emergency blanket.',
    motion: 'Three still illustrations slide or dissolve into place; rain overlay; no character walk cycle.',
    background: 'overhang',
    sfx: [{name: 'rain', phrase: 'Rain, wind', volume: 0.3}, {name: 'whoosh', phrase: 'Look for a safe place', volume: 0.5}, {name: 'whoosh', phrase: 'A tarp or emergency blanket', volume: 0.5}, {name: 'warning', phrase: 'Avoid dry riverbeds', volume: 0.35}],
  },
  {
    id: 'water', title: 'Find Safe Water', duration: 1290,
    narration: 'Water is essential. Clear-looking water is not necessarily safe to drink. Natural water may contain harmful microorganisms. Whenever possible, use a proper water filter, approved purification tablets, or boil water according to recognized safety guidance. Boiling does not remove chemical contamination. Never assume a river, stream, or lake is automatically safe.',
    visual: 'Stream, container, filter, purification tablets, boiling pot; treatment flow graphic.',
    motion: 'Camera pans across still props; animated arrows and labels; steam loop only.',
    background: 'stream',
    sfx: [{name: 'pop', phrase: 'Clear-looking water', volume: 0.5}, {name: 'pop', phrase: 'proper water filter', volume: 0.5}, {name: 'pop', phrase: 'approved purification tablets', volume: 0.5}, {name: 'pop', phrase: 'boil water', volume: 0.5}, {name: 'warning', phrase: 'Boiling does not remove chemical contamination', volume: 0.4}],
  },
  {
    id: 'warmth', title: 'Fire and Warmth', duration: 1380,
    narration: 'Fire can provide warmth, help prepare food, and attract attention, but it also comes with serious risks. A small mistake can start a wildfire. Consider weather, vegetation, local restrictions, and fire danger. Never light a fire when conditions make it unsafe. Warm clothing and an emergency blanket may be safer ways to stay warm.',
    visual: 'Cold forest evening; jacket, flashlight, lighter, waterproof matches, emergency blanket.',
    motion: 'Static character; light flicker only if a permitted, safe fire is depicted; slow camera drift.',
    background: 'dusk',
    sfx: [{name: 'pop', phrase: 'Fire can provide warmth', volume: 0.5}, {name: 'warning', phrase: 'A small mistake', volume: 0.4}, {name: 'pop', phrase: 'Consider weather', volume: 0.5}, {name: 'warning', phrase: 'Never light a fire', volume: 0.35}, {name: 'whoosh', phrase: 'Warm clothing', volume: 0.5}],
  },
  {
    id: 'food', title: 'Find Food', duration: 1380,
    narration: 'The wilderness contains plants, berries, and mushrooms. Some are edible; others are poisonous. Never eat a wild plant because an animal appears to be eating it. Never assume a berry is safe because it looks familiar. If you cannot identify it with reliable expert knowledge, do not eat it. Emergency food supplies are much safer.',
    visual: 'Unknown berries and mushrooms with warning symbol; emergency ration from backpack.',
    motion: 'Props appear as cut-ins; red warning mark draws on; character remains in held pose.',
    background: 'forest',
    sfx: [{name: 'pop', phrase: 'The wilderness contains plants', volume: 0.5}, {name: 'warning', phrase: 'Never eat a wild plant', volume: 0.4}, {name: 'warning', phrase: 'If you cannot identify it', volume: 0.35}, {name: 'ding', phrase: 'Emergency food supplies', volume: 0.4}],
  },
  {
    id: 'signal', title: 'Navigation and Signaling', duration: 1680,
    narration: 'If you have a working phone, contact local emergency services. Share your location or GPS coordinates if available. If you cannot contact anyone, use visual and sound signals. A whistle can attract attention without forcing you to shout. Three repeated whistle blasts can be used as a distress signal. A flashlight or reflective object may help rescuers locate you. Stay in a safe, visible place whenever possible.',
    visual: 'Map, compass, phone with no signal, whistle, mirror, flashlight, visible SOS marker.',
    motion: 'Slow pan across gear; signal symbols pulse; no running or walking animation.',
    background: 'forest',
    sfx: [{name: 'pop', phrase: 'If you have a working phone', volume: 0.5}, {name: 'pop', phrase: 'Share your location', volume: 0.5}, {name: 'whistle', phrase: 'A whistle can attract attention', volume: 0.5}, {name: 'pop', phrase: 'A flashlight or reflective object', volume: 0.5}],
  },
  {
    id: 'wildlife', title: 'Wildlife Safety', duration: 1380,
    narration: 'The wilderness is home to many wild animals. Respect their space. Never approach, feed, chase, or provoke wildlife. If you encounter a potentially dangerous animal, avoid sudden movements and do not run blindly. The correct response depends on the species and situation. Learn about local wildlife before visiting and observe animals from a safe distance.',
    visual: 'Alex and a distant wild animal separated by clear space; species-neutral warning icons.',
    motion: 'Hold both figures; slow camera pull-back; small attention cue around distance boundary.',
    background: 'meadow',
    sfx: [{name: 'whoosh', phrase: 'The wilderness is home', volume: 0.4}, {name: 'pop', phrase: 'Respect their space', volume: 0.5}, {name: 'warning', phrase: 'If you encounter a potentially dangerous animal', volume: 0.35}],
  },
  {
    id: 'kit', title: 'The Survival Kit', duration: 1500,
    narration: 'A well-prepared backpack can make an enormous difference. Carry drinking water and a way to treat additional water. Bring a first-aid kit, navigation tools, a flashlight, a whistle, and emergency shelter. Pack extra clothing, appropriate food, and essential personal supplies. Keep your phone charged and consider a backup power source. Tell someone your route and expected return time before leaving.',
    visual: 'Backpack opens; labeled survival items arranged neatly around it.',
    motion: 'Items pop or slide in sequentially; backpack stays still; camera remains mostly locked.',
    background: 'home',
    sfx: [{name: 'pop', phrase: 'drinking water', volume: 0.5}, {name: 'pop', phrase: 'first-aid kit', volume: 0.5}, {name: 'pop', phrase: 'a flashlight', volume: 0.5}, {name: 'pop', phrase: 'a whistle', volume: 0.5}, {name: 'pop', phrase: 'extra clothing', volume: 0.5}, {name: 'pop', phrase: 'Keep your phone charged', volume: 0.5}, {name: 'ding', phrase: 'Tell someone your route', volume: 0.4}],
  },
  {
    id: 'ending', title: 'The Final Lesson', duration: 1500,
    narration: 'Eventually, Alex hears something in the distance. A rescue team is approaching. He uses his whistle to attract their attention. This story teaches us something important. Survival is not about being the strongest person in the forest. It is about staying calm, protecting yourself, managing your resources, and making intelligent decisions. Prepare properly, respect nature, and always return safely.',
    visual: 'Rescue team appears far away; Alex signals; end card: STAY CALM. STAY PREPARED. STAY SAFE.',
    motion: 'Slow zoom-out; rescue team revealed by background cut; end card fades in.',
    background: 'meadow',
    sfx: [{name: 'whistle', phrase: 'He uses his whistle', volume: 0.6}, {name: 'whoosh', phrase: 'This story teaches us', volume: 0.4}, {name: 'ding', phrase: 'Prepare properly', volume: 0.5}],
  },
];

/** Scene start frames are derived from the durations so they can never drift apart. */
export const scenes: Scene[] = defs.reduce<Scene[]>((acc, def) => {
  const start = acc.length === 0 ? 0 : acc[acc.length - 1].start + acc[acc.length - 1].duration;
  acc.push({...def, start});
  return acc;
}, []);

export const TOTAL_FRAMES = scenes.reduce((sum, s) => sum + s.duration, 0);

/** Returns a list of human-readable problems; empty means the timeline is valid. */
export const validateTimeline = (): string[] => {
  const problems: string[] = [];
  const seconds = TOTAL_FRAMES / FPS;
  if (seconds < MIN_SECONDS || seconds > MAX_SECONDS) {
    problems.push(`Total duration ${seconds.toFixed(1)}s is outside ${MIN_SECONDS}-${MAX_SECONDS}s`);
  }
  const ids = new Set<string>();
  scenes.forEach((s, i) => {
    if (ids.has(s.id)) problems.push(`Duplicate scene id ${s.id}`);
    ids.add(s.id);
    if (!Number.isInteger(s.duration) || s.duration <= 0) problems.push(`Scene ${s.id} has invalid duration`);
    if (s.narration.trim().length === 0) problems.push(`Scene ${s.id} has no narration`);
    if (i > 0 && s.start !== scenes[i - 1].start + scenes[i - 1].duration) problems.push(`Scene ${s.id} start is not contiguous`);
    s.sfx.forEach((c) => {
      if (!s.narration.includes(c.phrase)) problems.push(`Scene ${s.id}: sfx phrase not found in narration: "${c.phrase}"`);
    });
    const words = s.narration.trim().split(/\s+/).length;
    const speechSeconds = (s.duration - 110) / FPS;
    const wps = words / speechSeconds;
    if (wps < 1.0 || wps > 3.3) problems.push(`Scene ${s.id}: narration pace ${wps.toFixed(2)} words/s is outside 1.0-3.3`);
  });
  return problems;
};
