/**
 * Generates English narration clips (one per scene) with espeak-ng and writes src/audio-manifest.json.
 * - Works offline once espeak-ng + ffmpeg are installed (apt-get install espeak-ng ffmpeg).
 * - If espeak-ng is missing the script exits successfully and the video renders without narration.
 * - If public/audio/narration.wav exists (your own recording) it is used as a full-length track instead.
 * The synthetic voice is a functional fallback; replace it with a professional recording for publishing.
 */
import {execFileSync, spawnSync} from 'node:child_process';
import {existsSync, mkdirSync, readFileSync, rmSync, writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {FPS, scenes} from '../src/timeline';
import {NARRATION_LEAD_IN, NARRATION_TAIL} from '../src/captions';

const root = join(__dirname, '..');
const outDir = join(root, 'public', 'audio', 'narration');
const manifestPath = join(root, 'src', 'audio-manifest.json');

type Manifest = {fullTrack: string | null; narration: Record<string, {file: string; speechFrames: number}>};
const write = (m: Manifest) => writeFileSync(manifestPath, JSON.stringify(m, null, 2) + '\n');
const has = (cmd: string, arg = '--version') => spawnSync(cmd, [arg], {stdio: 'ignore'}).status === 0;

if (existsSync(join(root, 'public', 'audio', 'narration.wav'))) {
  console.log('Found public/audio/narration.wav - using it as the full narration track.');
  write({fullTrack: 'audio/narration.wav', narration: {}});
  process.exit(0);
}
if (!has('espeak-ng') || !has('ffmpeg', '-version') || !has('ffprobe', '-version')) {
  console.warn('espeak-ng/ffmpeg not found - rendering WITHOUT narration (subtitles, music and SFX still included).');
  write({fullTrack: null, narration: {}});
  process.exit(0);
}

mkdirSync(outDir, {recursive: true});
const duration = (file: string) =>
  parseFloat(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file]).toString());
const speak = (text: string, wpm: number, file: string) =>
  execFileSync('espeak-ng', ['-v', 'en-us', '-s', String(wpm), '-p', '42', '-w', file, text]);

const manifest: Manifest = {fullTrack: null, narration: {}};
for (const scene of scenes) {
  const targetSec = (scene.duration - NARRATION_LEAD_IN - NARRATION_TAIL) / FPS;
  const raw = join(outDir, `${scene.id}.raw.wav`);
  const out = join(outDir, `${scene.id}.wav`);
  let wpm = 140;
  speak(scene.narration, wpm, raw);
  const d = duration(raw);
  // Fit the speech to the scene's narration window by adjusting the speaking rate.
  wpm = Math.max(85, Math.min(190, Math.round(wpm * (d / targetSec))));
  speak(scene.narration, wpm, raw);
  let len = duration(raw);
  const tempo = len > targetSec ? Math.min(1.25, len / targetSec) : 1;
  execFileSync('ffmpeg', ['-y', '-v', 'error', '-i', raw, '-af', `atempo=${tempo.toFixed(4)},aresample=44100,volume=1.8`, '-ac', '1', out]);
  len = duration(out);
  rmSync(raw);
  manifest.narration[scene.id] = {file: `audio/narration/${scene.id}.wav`, speechFrames: Math.round(len * FPS)};
  console.log(`${scene.id}: ${len.toFixed(1)}s of speech (target ${targetSec.toFixed(1)}s, ${wpm} wpm)`);
}
write(manifest);
console.log('Narration generated.');
