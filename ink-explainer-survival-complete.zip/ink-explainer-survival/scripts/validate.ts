import {existsSync, readFileSync} from 'node:fs';
import {join} from 'node:path';
import {FPS, scenes, TOTAL_FRAMES, validateTimeline} from '../src/timeline';

const root = join(__dirname, '..');
const problems = validateTimeline();

// Composition ID must be exactly "SurvivalInTheWild" and registered with the expected settings.
const rootSrc = readFileSync(join(root, 'src', 'Root.tsx'), 'utf8');
if (!/id="SurvivalInTheWild"/.test(rootSrc)) problems.push('Composition id "SurvivalInTheWild" not found in src/Root.tsx');
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')) as {scripts: Record<string, string>};
if (!pkg.scripts.render.includes('SurvivalInTheWild')) problems.push('package.json render script does not reference SurvivalInTheWild');

// Required static assets.
for (const f of ['music.wav', 'sfx/pop.wav', 'sfx/whoosh.wav', 'sfx/whistle.wav', 'sfx/ding.wav', 'sfx/warning.wav', 'sfx/rain.wav', 'sfx/birds.wav']) {
  if (!existsSync(join(root, 'public', 'audio', f))) problems.push(`Missing public/audio/${f} (run: python3 scripts/make-audio.py)`);
}

// Every narration cue used by the scene code must exist in that scene's narration.
const sceneSrc = readFileSync(join(root, 'src', 'scenes', 'Scenes.tsx'), 'utf8');
const bodies = sceneSrc.split(/export const (\w+)Scene: React\.FC/).slice(1);
for (let i = 0; i < bodies.length; i += 2) {
  const id = bodies[i].toLowerCase();
  const body = bodies[i + 1];
  const scene = scenes.find((s) => s.id === id);
  if (!scene) { problems.push(`Scene component ${bodies[i]}Scene has no timeline entry`); continue; }
  for (const m of [...body.matchAll(/\bc\('([^']+)'\)/g), ...body.matchAll(/phrase: '([^']+)'/g)]) {
    if (!scene.narration.includes(m[1])) problems.push(`Scene ${id}: cue phrase not in narration: "${m[1]}"`);
  }
}
for (const s of scenes) if (!new RegExp(`${s.id}:\\s*\\w+Scene`).test(sceneSrc)) problems.push(`Scene ${s.id} not registered in SCENE_COMPONENTS`);

const seconds = TOTAL_FRAMES / FPS;
console.log(`Scenes: ${scenes.length}   Frames: ${TOTAL_FRAMES}   Duration: ${Math.floor(seconds / 60)}:${String(Math.round(seconds % 60)).padStart(2, '0')}`);
if (problems.length > 0) {
  console.error('Validation FAILED:\n - ' + problems.join('\n - '));
  process.exit(1);
}
console.log('Validation OK');
