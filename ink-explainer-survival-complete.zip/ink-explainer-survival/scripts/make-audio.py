#!/usr/bin/env python3
"""Generates the original background music loop and sound effects (no external assets, no licences).
Run: python3 scripts/make-audio.py   (needs numpy + scipy)"""
import numpy as np
from scipy.io import wavfile
import os

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'audio')
os.makedirs(os.path.join(OUT, 'sfx'), exist_ok=True)
rng = np.random.default_rng(7)  # deterministic

def env(n, a=0.01, r=0.3):
    e = np.ones(n)
    na, nr = int(a * SR), int(r * SR)
    if na: e[:na] = np.linspace(0, 1, na)
    if nr: e[-nr:] = np.linspace(1, 0, nr)
    return e

def tone(freq, dur, kind='sine'):
    t = np.arange(int(dur * SR)) / SR
    w = np.sin(2 * np.pi * freq * t)
    if kind == 'soft':
        w += 0.3 * np.sin(4 * np.pi * freq * t) + 0.1 * np.sin(6 * np.pi * freq * t)
    return w

def save(name, x, vol=0.8):
    x = x / (np.max(np.abs(x)) + 1e-9) * vol
    wavfile.write(os.path.join(OUT, name), SR, (x * 32767).astype(np.int16))

# ---- Music: calm 8-bar loop, 80 BPM, Am - F - C - G pads + gentle pluck arpeggio ----
bpm = 80
beat = 60 / bpm
bar = 4 * beat
chords = [
    [220.00, 261.63, 329.63],  # Am
    [174.61, 220.00, 261.63],  # F
    [261.63, 329.63, 392.00],  # C
    [196.00, 246.94, 293.66],  # G
]
bars = 8
total = int(bars * bar * SR)
music = np.zeros(total)
for b in range(bars):
    ch = chords[b % 4]
    start = int(b * bar * SR)
    for f in ch:
        n = int(bar * SR)
        seg = tone(f / 2, bar, 'soft') * env(n, 0.6, 0.8) * 0.18
        music[start:start + n] += seg[:total - start][:n]
    for i in range(8):  # eighth-note plucks
        f = ch[[0, 1, 2, 1, 0, 2, 1, 2][i]] * 2
        s = start + int(i * beat / 2 * SR)
        d = 0.9
        n = int(d * SR)
        t = np.arange(n) / SR
        p = (np.sin(2 * np.pi * f * t) + 0.25 * np.sin(4 * np.pi * f * t)) * np.exp(-t * 4.5) * 0.14
        end = min(total, s + n)
        music[s:end] += p[:end - s]
# seamless loop: crossfade tail into head
xf = int(0.5 * SR)
music[:xf] += music[-xf:] * np.linspace(1, 0, xf)[::-1] * 0
music = music[:total]
fade = np.linspace(0, 1, 200)
music[:200] *= fade
music[-200:] *= fade[::-1]
save('music.wav', music, 0.6)

# ---- SFX ----
n = int(0.25 * SR); t = np.arange(n) / SR
save('sfx/pop.wav', np.sin(2 * np.pi * (300 + 900 * t / 0.25) * t) * np.exp(-t * 18), 0.7)

n = int(0.5 * SR); t = np.arange(n) / SR
whoosh = rng.standard_normal(n)
k = 60; whoosh = np.convolve(whoosh, np.ones(k) / k, mode='same')
save('sfx/whoosh.wav', whoosh * np.sin(np.pi * t / 0.5) ** 2, 0.7)

# whistle: three blasts
w = []
for _ in range(3):
    d = 0.35; t = np.arange(int(d * SR)) / SR
    vib = np.sin(2 * np.pi * 2900 * t + 3 * np.sin(2 * np.pi * 35 * t))
    w.append(vib * env(len(t), 0.02, 0.05)); w.append(np.zeros(int(0.2 * SR)))
save('sfx/whistle.wav', np.concatenate(w), 0.6)

n = int(0.6 * SR); t = np.arange(n) / SR
save('sfx/ding.wav', (np.sin(2 * np.pi * 880 * t) + 0.4 * np.sin(2 * np.pi * 1320 * t)) * np.exp(-t * 6), 0.6)

n = int(0.5 * SR); t = np.arange(n) / SR
save('sfx/warning.wav', (np.sin(2 * np.pi * 220 * t) * np.sign(np.sin(2 * np.pi * 8 * t))) * env(n, 0.01, 0.1), 0.5)

# rain ambience 10 s
n = 10 * SR
r = rng.standard_normal(n)
r = np.convolve(r, np.ones(4) / 4, mode='same')
save('sfx/rain.wav', r, 0.4)

# birds ambience 8 s: few chirps
n = 8 * SR; b = np.zeros(n)
for s in [0.5, 1.1, 2.8, 3.3, 3.7, 5.5, 6.4]:
    d = 0.18; t = np.arange(int(d * SR)) / SR
    f = 3200 + 900 * np.sin(2 * np.pi * 14 * t)
    c = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 12)
    i = int(s * SR); b[i:i + len(c)] += c
save('sfx/birds.wav', b, 0.5)
print('audio generated')
